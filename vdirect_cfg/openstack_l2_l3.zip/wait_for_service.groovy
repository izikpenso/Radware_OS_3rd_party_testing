import com.radware.alteon.beans.adc.*;
import com.radware.alteon.api.*;
import com.radware.alteon.sdk.*
import com.radware.alteon.sdk.rpm.*
import com.radware.alteon.api.impl.AlteonCliUtils;
import com.radware.alteon.cli.CliSession;



// Guarantees that the service is provisioned or else throws an exception
logger.info("Provisioning service...")
service.provision()
logger.info("Provisioning service complete")


def timeout = 5 * 60 * 1000

// The timeout can optionally be passed to the script.
// Note that the timeout does NOT include time taken to provision the service
if (binding.variables.containsKey('timeout')) {
	timeout = binding.variables.get('timeout')
}


def start = System.currentTimeMillis()

logger.info("Locking primary ADC ${service.primary.address}...")
factory.lock(service.primary, true)
logger.info("Locked primary ADC ${service.primary.address}")

try {
	if (service.request.ha) {
		logger.info("Locking secondary ADC ${service.secondary.address}...")
		factory.lock(service.secondary, true)
		logger.info("Locked secondary ADC ${service.secondary.address}")
	}
	try {
	    logger.info("Validating primary SSH available ${service.primary.address}")
	    validateAdcCLIConnection(service.primary, start + timeout - System.currentTimeMillis())
	    logger.info("Validated primary ${service.primary.address}")
			
		if (service.request.ha) {
			logger.info("Validating secondary SSH available ${service.secondary.address}")
			validateAdcCLIConnection(service.secondary, start + timeout - System.currentTimeMillis())
			logger.info("Validated secondary ${service.secondary.address}")
		}
	} finally {
		if (service.request.ha)
			factory.unlock(service.secondary)
	}
} finally {
	factory.unlock(service.primary)
}


def validateAdcCLIConnection (AdcCLIConnection connection, long timeout) {
	
	def SLEEP_TIME = 2000
	def start = System.currentTimeMillis()
	def connected = false
	while (!connected && (System.currentTimeMillis() - start < timeout)) {
		CliSession s = new CliSession(AlteonCliUtils.convertConnection(connection))
		try {
			s.connect()
			s.close()
			connected = true
		} catch (Exception e) {
			sleep(SLEEP_TIME)
		}
	}
	if (!connected)
        throw new AdcConnectionException("SSH connection timeout to ${connection.address} in ${System.currentTimeMillis() - start} ms")
}
