package com.radware.vdirect.os.lb.v2.structures.persistent

import com.radware.alteon.workflow.impl.java.Param;

public class GroupRealServers {
	@Param(type="int", defaultValue="80")
	public Integer port;
	@Param(defaultValue="[]")
	public RealServer[] realServers;
}
