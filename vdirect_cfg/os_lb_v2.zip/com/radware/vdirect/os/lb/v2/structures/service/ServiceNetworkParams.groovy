package com.radware.vdirect.os.lb.v2.structures.service

import com.radware.alteon.workflow.impl.java.Param;

public class ServiceNetworkParams {
	@Param(type="string", prompt="Service network type", defaultValue="portgroup")
	public String type;
	@Param(type="string[]", prompt="Service network portgroups", defaultValue=('DATA_NETWORK'))
	public String[] portgroups;
}
