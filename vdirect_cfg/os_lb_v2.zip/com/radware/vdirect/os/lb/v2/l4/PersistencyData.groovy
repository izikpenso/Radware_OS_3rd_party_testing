package com.radware.vdirect.os.lb.v2.l4

import java.util.Map;
import java.beans.PersistenceDelegate;
import java.util.regex.Matcher
import java.util.regex.Pattern

import org.apache.commons.net.util.SubnetUtils;
import org.springframework.beans.factory.annotation.Autowired;

import groovy.transform.ToString
import groovy.transform.EqualsAndHashCode

import com.radware.alteon.beans.adc.*;
import com.radware.alteon.api.*;
import com.radware.alteon.sdk.*
import com.radware.alteon.sdk.containers.SoftAdcInfo;
import com.radware.alteon.sdk.impl.resources.wrapped.WrappedAdcService;
import com.radware.alteon.sdk.rpm.*
import com.radware.alteon.workflow.impl.DeviceConnection;
import com.radware.alteon.workflow.impl.WorkflowAdaptor;
import com.radware.alteon.workflow.impl.java.ConfigurationTemplate;
import com.radware.alteon.api.impl.AlteonCliUtils;
import com.radware.alteon.cli.CliSession;
import com.radware.beans.IReadableBean;
import com.radware.logging.VDirectLogger;
import com.radware.osjava.nova.command.AggregatesExtension.AddHost;
import com.radware.osjava.nova.model.KeyPair;
import com.radware.vdirect.client.api.IAdcSessionBoundObjectFactory;
import com.radware.vdirect.os.lb.v2.l4.StaticRoutes;
import com.radware.vdirect.os.lb.v2.structures.l4.HealthMonitorParams;
import com.radware.vdirect.os.lb.v2.structures.l4.ListenerParams;
import com.radware.vdirect.os.lb.v2.structures.l4.MemberParams;
import com.radware.vdirect.os.lb.v2.structures.l4.RealServerParams;
import com.radware.vdirect.os.lb.v2.structures.persistent.StaticRoute;
import com.radware.vdirect.os.lb.v2.structures.persistent.LBVirt;
import com.radware.vdirect.os.lb.v2.structures.persistent.GroupRealServers;
import com.radware.vdirect.os.lb.v2.structures.persistent.RealServer;

public class PersistencyData {
	
	public static final String DISASSOCIATE_HM = "disassociate"
	public static final String ASSOCIATE_HM = "associate"
	public static final String UPDATE_HM = "update"
	
	WorkflowAdaptor workflow
	DeviceConnection connection

	// <VirtName, LBVirt>
	Map<String, LBVirt> virtsMap
	// <VirtName, Default TLS Certificate container id>
	Map<String, String> virtsDefaultCertMap
	// <VirtName, List of SNI Certificate container ids>
	Map<String, String[]> virtsSNICertsMap
	// <VirtName, List of Intermediate certificates>
	Map<String, String[]> virtsIntermCaCertsMap
	// <GroupName,<RealServerName, RealServer>>
	Map<String, Map<String, RealServer>> groupRealServersMap
	// <GroupName, HealthMonitorParams>
	Map<String, HealthMonitorParams> groupHMsMap
	// <Subnet, StaticRoute>
	Map<String, StaticRoute> staticRoutesMap
	
	public PersistencyData (Map<String, StaticRoute> static_routes, WorkflowAdaptor workflow) {
		this.workflow = workflow
		this.connection = connection

		this.staticRoutesMap = static_routes;
		getWFPersistentData()
	}
	
	private void getWFPersistentData () {
		this.virtsMap = (Map<String, LBVirt>)workflow['lb_virts']
		this.virtsDefaultCertMap = (Map<String, String>)workflow['lb_virts_default_cert']
		this.virtsSNICertsMap = (Map<String, LinkedHashMap<String, String>>)workflow['lb_virts_sni_certs']
		this.virtsIntermCaCertsMap = (Map<String, HashMap<String, String>>)workflow['lb_virts_intermca_certs']
		this.groupRealServersMap = (Map<String, Map<String, RealServer>>)workflow['group_real_servers']
		this.groupHMsMap = (Map<String, HealthMonitorParams>)workflow['group_hms']
	}

	public void persistWFPersistentData () {
		workflow['lb_virts'] = virtsMap
		workflow['lb_virts_default_cert'] = virtsDefaultCertMap
		workflow['lb_virts_sni_certs'] = virtsSNICertsMap
		workflow['lb_virts_intermca_certs'] = virtsIntermCaCertsMap
		workflow['group_real_servers'] = groupRealServersMap
		workflow['group_hms'] = groupHMsMap
	}
	
	public void clearWFPersistentData () {
		this.virtsMap.clear()
		this.virtsDefaultCertMap.clear()
		this.virtsSNICertsMap.clear()
		this.virtsIntermCaCertsMap.clear()
		this.groupRealServersMap.clear()
		this.groupHMsMap.clear()
		
		persistWFPersistentData()
	}
	
	public boolean addNewStaticRouteData (MemberParams memberParams) {
		if (this.staticRoutesMap.containsKey(memberParams.subnet)) {
			return false
		}
		StaticRoute staticRoute = new StaticRoute()
		staticRoute.destinationIp = memberParams.subnet
		staticRoute.gatewayIp = memberParams.gw
		staticRoute.maskIp = memberParams.mask
		this.staticRoutesMap.put(memberParams.subnet, staticRoute)
		
		return true
	}

	public StaticRoute getStaticRouteData (String destinationIp) {
		return this.staticRoutesMap.get(destinationIp)
	}

	public void addNewVirtData (String virtName, String port, String groupName) {
		LBVirt lbVirt = new LBVirt()
		lbVirt.name = virtName
		lbVirt.port = Integer.valueOf(port)
		lbVirt.groupName = groupName
		this.virtsMap.put(virtName, lbVirt)

		this.groupRealServersMap.put(groupName, new HashMap<String, RealServer>())
	}

	public void removeVirtData (String groupName, String virtName) {
		this.virtsMap.remove(virtName)
		this.groupRealServersMap.remove(groupName)
	}

	public LBVirt getVirtData (String virtName) {
		return this.virtsMap.get(virtName)
	}
	
	public void addVirtDefaultCertId (String virtName, String certId) {
		this.virtsDefaultCertMap.put(virtName, certId)
	}

	public void removeVirtDefaultCertId (String virtName) {
		this.virtsDefaultCertMap.remove(virtName)
	}

	public String getVirtDefaultCertId (String virtName) {
		return this.virtsDefaultCertMap.get(virtName)
	}

	public void addVirtSNICertIds (String virtName, String[] certs) {
		this.virtsSNICertsMap.put(virtName, certs)
	}

	public void removeVirtSNICertIds (String virtName) {
		this.virtsSNICertsMap.remove(virtName)
	}

	public String[] getVirtSNICertIds (String virtName) {
		String[] val = this.virtsSNICertsMap.get(virtName)
		if (val == null) {
			return []
		}
		else {
			return val
		}
	}

	public void addVirtIntermCaCertIds (String virtName, String[] intermcaCertIds) {
		this.virtsIntermCaCertsMap.put(virtName, intermcaCertIds)
	}

	public void removeVirtIntermCaCertIds (String virtName) {
		this.virtsIntermCaCertsMap.remove(virtName)
	}

	public String[] getVirtIntermCaCertIds (String virtName) {
		String[] val = this.virtsIntermCaCertsMap.get(virtName)
		if (val == null) {
			return []
		}
		else {
			return val
		}
	}

	public Set<String> getVirtKeys () {
		return new HashSet<String>(this.virtsMap.keySet())
	}

	public Set<String> getDeletedVirtKeys (Set<String> newKeysSet) {
		Set<String> dels = new HashSet<String>(this.virtsMap.keySet())
		dels.removeAll(newKeysSet)
		return dels
	}
	
	public Set<String> getNewVirtKeys (Set<String> newKeysSet) {
		Set<String> news = new HashSet<String>(newKeysSet)
		news.removeAll(this.virtsMap.keySet())
		return news
	}
		
	public void addNewRealServerData (String groupName, RealServerParams realServerParams) {
		RealServer realServer = new RealServer()
		
		realServer.id = realServerParams.id
		realServer.address = realServerParams.address
		realServer.name = realServerParams.name
		realServer.port = realServerParams.protocol_port
		
		Map<String, RealServer> realServers = this.groupRealServersMap.get(groupName)
		realServers.put(realServerParams.name, realServer)
		this.groupRealServersMap.put(groupName, realServers)
	}

	public void removeRealServerData (String groupName, String realServerName) {
		Map<String, RealServer> realServers = this.groupRealServersMap.get(groupName)
		realServers.remove(realServerName)
		this.groupRealServersMap.put(groupName, realServers)
	}

	public Set<String> getDeletedGroupRealServersKeys (String groupName, Set<String> newKeysSet) {
		Set<String> dels = new HashSet<String>(this.groupRealServersMap.get(groupName).keySet())
		dels.removeAll(newKeysSet)
		return dels
	}
	
	public Set<String> getNewGroupRealServersKeys (String groupName, Set<String> newKeysSet) {
		Set<String> news = new HashSet<String>(newKeysSet)
		news.removeAll(this.groupRealServersMap.get(groupName).keySet())
		return news
	}

	public Set<String> getUpdatedGroupRealServersKeys (String groupName, Set<String> newKeysSet) {
		Set<String> updates = new HashSet<String>(this.groupRealServersMap.get(groupName).keySet())
		updates.retainAll(newKeysSet)
		return updates
	}

	public Map<String, RealServer> getGroupRealServersData (String groupName) {
		return this.groupRealServersMap.get(groupName)
	}
	
	public HealthMonitorParams setHealthMonitorData (String groupName, HealthMonitorParams hmParams) {
		return this.groupHMsMap.put(groupName, hmParams)
	}
	
	public HealthMonitorParams getHealthMonitorData (String groupName) {
		return this.groupHMsMap.get(groupName)
	}

}