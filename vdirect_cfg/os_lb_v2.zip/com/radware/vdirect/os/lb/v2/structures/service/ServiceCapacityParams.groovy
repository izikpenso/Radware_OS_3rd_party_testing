package com.radware.vdirect.os.lb.v2.structures.service

import com.radware.alteon.workflow.impl.java.Param;

public class ServiceCapacityParams {
	@Param(type="int", prompt="Service throughput", defaultValue="1000")
	public int throughput;
	@Param(type="int", prompt="Service SSL throughput", defaultValue="200")
	public int sslThroughput;
	@Param(type="int", prompt="Service compression throughput", defaultValue="100")
	public int compressionThroughput;
	@Param(type="int", prompt="Service cache", defaultValue="200")
	public int cache;
}