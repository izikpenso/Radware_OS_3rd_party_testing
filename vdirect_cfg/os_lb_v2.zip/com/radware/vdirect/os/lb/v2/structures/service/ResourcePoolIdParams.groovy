package com.radware.vdirect.os.lb.v2.structures.service

import com.radware.alteon.sdk.rpm.AdcAcceptableType;
import com.radware.alteon.workflow.impl.java.Param;

public class ResourcePoolIdParams {
	@Param(type="string", prompt="Service Resource Pool id", defaultValue="")
	public String id;
}
