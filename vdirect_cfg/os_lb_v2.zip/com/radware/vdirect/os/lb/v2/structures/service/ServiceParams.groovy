package com.radware.vdirect.os.lb.v2.structures.service

import java.util.Set;

import com.radware.alteon.sdk.AdcResourceId;
import com.radware.alteon.workflow.impl.java.Param;


public class ServiceParams {
	@Param(type="string", prompt="Service name", defaultValue="srv_UNDEFINED")
	public String name;
	@Param(type="string", prompt="Service tenant id", defaultValue="_UNDEFINED_")
	public String tenantId;
	@Param(type="bool", prompt="Is service highly available?", defaultValue="false")
	public boolean haPair;
	@Param(type="bool", prompt="Is session mirroring enabled?", defaultValue="false")
	public boolean sessionMirroringEnabled;
	@Param(prompt="Service resource pool ids", defaultValue="[]")
	public ResourcePoolIdParams[] resourcePoolIds;
	@Param(type="int", min=-1, prompt="Service ISL vLAN", defaultValue="-1")
	public int islVlan;
	@Param(prompt="Service capacity, network and ADC specification")
	public ServiceSpecParams primary;
}

