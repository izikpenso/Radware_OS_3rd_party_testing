package com.radware.vdirect.os.lb.v2

import java.util.Map;

import com.radware.alteon.workflow.impl.DeviceConnection;
import com.radware.alteon.workflow.impl.WorkflowAdaptor;
import com.radware.alteon.workflow.impl.java.ConfigurationTemplate;
import com.radware.logging.VDirectLogger;
import com.radware.vdirect.os.lb.v2.structures.l4.HealthMonitorParams;
import com.radware.vdirect.os.lb.v2.structures.l4.RealServerParams;
import com.radware.vdirect.os.lb.v2.structures.persistent.StaticRoute;

public class DeviceConfigurator {
	
	public static final String DISASSOCIATE_HM = "disassociate"
	public static final String ASSOCIATE_HM = "associate"
	public static final String UPDATE_HM = "update"
	
	WorkflowAdaptor workflow
	DeviceConnection connection
	
	public DeviceConfigurator (DeviceConnection connection, WorkflowAdaptor workflow) {
		this.workflow = workflow
		this.connection = connection
	}

	public Integer getFreeIndex (String beanName, Integer startingIndex) { 
		return connection.getFreeIndex(beanName, startingIndex)
	}

	public void configureVirt (Integer virtIndex, Integer groupIndex,
		String port, String protocol,
		String portAlgorythm, pool_admin_state_up,
		String session_persistence_type,
		String session_persistence_cookie_name) {
							  
		ConfigurationTemplate template = workflow.getTemplate("com/radware/vdirect/os/lb/v2/openstack_manage_l4.vm")
		template.parameters = [
			'adc': this.connection,
			'virtId': virtIndex,
			'groupId': groupIndex,
			'virtServerEnabled': workflow['admin_state_up'],
			'vip': workflow['vip_address'],
			'pip_address': workflow['pip_address'],
			'virtSvcPort': port,
			'virtSvcType': protocol,
			'svcPortAlgorithm': portAlgorythm,
			'groupEnabled': pool_admin_state_up,
			'virtSvcPersistMethod': session_persistence_type,
			'virtSvcCookieName': session_persistence_cookie_name]
		template.run()
	}
	
	public void teardownVirt (Integer groupId, Integer virtId, Integer[] realServerIdsArray) {

		ConfigurationTemplate template = workflow.getTemplate("com/radware/vdirect/os/lb/v2/openstack_teardown_l4.vm")
		template.parameters = [
			'adc': this.connection,
			'groupId': groupId,
			'virtId': virtId,
			'curRealServerIds': realServerIdsArray]
		template.run()
   }

	public void configureGroup (Integer groupId, boolean groupEnabled,
			RealServerParams[] newRealServers,
			RealServerParams[] updatedRealServers,
			Integer[] deletedRealServersIds) {

		ConfigurationTemplate template = workflow.getTemplate("com/radware/vdirect/os/lb/v2/openstack_manage_rips.vm")
		template.parameters = [
			'adc': this.connection,
			'groupId': groupId,
			'groupEnabled': groupEnabled,
			'newRealServers': newRealServers,
			'updatedRealServers': updatedRealServers,
			'deletedRealServersIds': deletedRealServersIds]
		template.run()
	}

	public void configureHM (HealthMonitorParams hmParams, Integer groupId,	String action) {
		ConfigurationTemplate template = workflow.getTemplate("com/radware/vdirect/os/lb/v2/openstack_manage_hm.vm")
		template.parameters = [
			'adc': this.connection,
			'hm': hmParams,
			'groupId': groupId,
			'action': action]
		template.run()
	}
	
	public void configureStaticRoutes (StaticRoute[] staticRoutesArray) {

		ConfigurationTemplate template = workflow.getTemplate("com/radware/vdirect/os/lb/v2/openstack_manage_static_routes.vm")
		template.parameters = [
			'adc': this.connection,
			'new_static_routes': staticRoutesArray]
		template.run()
	}
}