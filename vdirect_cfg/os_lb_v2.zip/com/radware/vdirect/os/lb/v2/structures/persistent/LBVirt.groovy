package com.radware.vdirect.os.lb.v2.structures.persistent

import com.radware.alteon.workflow.impl.java.Param;

public class LBVirt {
	@Param(type="int", defaultValue="80")
	public Integer port;

	// Legacy
	//@Param(type="int", defaultValue="1")
	//public Integer index;
	//@Param(type="int", defaultValue="1")
	//public Integer groupIndex;
	
	@Param(type="string", defaultValue="")
	public String name;
	@Param(type="string", defaultValue="")
	public String groupName;
}