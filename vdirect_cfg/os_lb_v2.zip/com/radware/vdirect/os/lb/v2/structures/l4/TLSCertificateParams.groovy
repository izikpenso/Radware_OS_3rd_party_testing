package com.radware.vdirect.os.lb.v2.structures.l4

import com.radware.alteon.workflow.impl.java.Param;

public class TLSCertificateParams {
	@Param(type="string", prompt="Certificate id", defaultValue="")
	public String id;
	@Param(type="string", prompt="Certificate", defaultValue="", format="pem")
	public String certificate;
	@Param(type="string", prompt="Intermediates", defaultValue="")
	public String intermediates;
	@Param(type="string", prompt="Private key", defaultValue="", format="pem")
	public String private_key;
	@Param(type="string", prompt="Private key passphrase", defaultValue="pass", format="password")
	public String passphrase;
}