package com.radware.vdirect.os.lb.v2.structures.l4

import com.radware.alteon.workflow.impl.java.Param;

public class HealthMonitorParams {
	@Param(type="string", prompt="Health monitors UUID", defaultValue="none")
	public String id;
	@Param(type="string", prompt="Health monitor type", defaultValue="HTTP", values=["PING", "TCP", "HTTP", "HTTPS"])
	public String type;
	@Param(type="int", prompt="Health monitor delay", defaultValue="10")
	public int delay;
	@Param(type="int", prompt="Health monitor timeout", defaultValue="20")
	public int timeout;
	@Param(type="int", prompt="Health monitor max retries", defaultValue="3")
	public int max_retries;
	@Param(type="bool", prompt="Is health monitor enabled?", defaultValue="true")
	public boolean admin_state_up;
	@Param(type="string", prompt="Health monitor url path", defaultValue="/")
	public String url_path;
	@Param(type="string", prompt="Health monitor http method", defaultValue="GET")
	public String http_method;
	@Param(type="string", prompt="Health monitor expected codes", defaultValue="200")
	public String expected_codes;
}
