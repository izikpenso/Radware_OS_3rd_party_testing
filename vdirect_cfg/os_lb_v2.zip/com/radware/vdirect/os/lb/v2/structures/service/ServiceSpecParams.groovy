package com.radware.vdirect.os.lb.v2.structures.service

import com.radware.alteon.sdk.AdcInstanceType;
import com.radware.alteon.sdk.rpm.AdcAcceptableType;
import com.radware.alteon.workflow.impl.java.Param;

public class ServiceSpecParams {
	@Param(prompt="Service capacity parameters")
	public ServiceCapacityParams capacity;
	@Param(prompt="Service network parameters")
	public ServiceNetworkParams network;
	@Param(type="string", prompt="Service ADC type", defaultValue="VA", values=["VA", "VX", "Dedicated"])
	public String adcType;
	@Param(type="string", prompt="Service acceptable ADC", defaultValue="Exact", values=["Any", "Exact", "BetterThan", "WorseThan"])
	public String acceptableAdc;
}