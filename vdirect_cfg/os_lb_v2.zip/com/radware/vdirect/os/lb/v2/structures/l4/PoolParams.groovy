package com.radware.vdirect.os.lb.v2.structures.l4

import com.radware.alteon.workflow.impl.java.Param;

public class PoolParams {
	@Param(type="string", prompt="Pool protocol", defaultValue="HTTP", values=["HTTP", "HTTPS", "TCP"])
	public String protocol;
	@Param(type="string", prompt="Pool load balancing algorithm", defaultValue="ROUND_ROBIN", values=["ROUND_ROBIN", "LEAST_CONNECTIONS", "SOURCE_IP"])
	public String lb_algorithm;
	@Param(type="bool", prompt="Is Pool enabled?", defaultValue="true")
	public boolean admin_state_up;
	@Param(prompt="Pool health monitor", defaultValue='{"id": "none", "type": "HTTP", "delay": 10, "timeout": 20, "max_retries": 3, "admin_state_up": "true", "url_path": "/", "http_method": "GET", "expected_codes": "200"}')
	//@Param(prompt="Pool health monitor",  required=false)
	public HealthMonitorParams healthmonitor;
	@Param(prompt="Pool session persistency", defaultValue='{"type": "none", "cookie_name": "none"}')
	public SessionPersistencyParams sessionpersistence;
	@Param(prompt="Pool members")
	public MemberParams[] members;
}