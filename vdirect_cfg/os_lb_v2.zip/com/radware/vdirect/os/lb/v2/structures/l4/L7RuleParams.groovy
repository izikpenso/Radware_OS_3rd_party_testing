package com.radware.vdirect.os.lb.v2.structures.l4

import com.radware.alteon.workflow.impl.java.Param;

public class L7RuleParams {
	@Param(type="string", prompt="Rule id", defaultValue="")
	public String id;
	@Param(type="string", prompt="Rule type", defaultValue="HOST_NAME", values=["HOST_NAME", "PATH", "FILE_TYPE", "HEADER", "COOKIE"])
	public String type;
	@Param(type="string", prompt="Rule compare type", defaultValue="EQUAL_TO", values=["REGEX", "STARTS_WITH", "ENDS_WITH", "CONTAINS", "EQUAL_TO"])
	public String compare_type;
	@Param(type="string", prompt="Key", defaultValue="None")
	public String key;
	@Param(type="string", prompt="Value")
	public String value;
	@Param(type="bool", prompt="Is rule enabled?", defaultValue="true")
	public boolean admin_state_up;
}