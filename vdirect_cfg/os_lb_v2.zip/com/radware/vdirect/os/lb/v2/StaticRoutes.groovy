package com.radware.vdirect.os.lb.v2

import org.apache.commons.net.util.SubnetUtils;
import org.springframework.beans.factory.annotation.Autowired;

import groovy.transform.ToString
import groovy.transform.EqualsAndHashCode

import com.radware.alteon.beans.adc.*;
import com.radware.alteon.api.*;
import com.radware.alteon.sdk.*
import com.radware.alteon.sdk.containers.SoftAdcInfo;
import com.radware.alteon.sdk.impl.resources.wrapped.WrappedAdcService;
import com.radware.alteon.sdk.rpm.*
import com.radware.alteon.workflow.impl.DeviceConnection;
import com.radware.alteon.workflow.impl.WorkflowAdaptor;
import com.radware.alteon.api.impl.AlteonCliUtils;
import com.radware.alteon.cli.CliSession;
import com.radware.logging.VDirectLogger;
import com.radware.osjava.nova.model.KeyPair;
import com.radware.vdirect.client.api.IAdcSessionBoundObjectFactory;
import com.radware.vdirect.os.lb.v2.structures.persistent.StaticRoute;

public class StaticRoutes {

	public static final String PRIMARY = "primary"
	public static final String SECONDARY = "secondary"
		
	public static Map<String, StaticRoute> getStaticRoutes (DeviceConnection connection) {
		Map<String, StaticRoute> retVal = new HashMap<String, StaticRoute>()
		IpNewCfgStaticRouteEntry ipv4staticRouteBean
		Ipv6NewCfgStaticRouteEntry ipv6staticRouteBean
		StaticRoute staticRoute;
		
		List<IpNewCfgStaticRouteEntry> ipv4staticRouteBeans = connection.readAllBeans('IpNewCfgStaticRouteEntry')
		Iterator<IpNewCfgStaticRouteEntry> ipv4staticRouteBeansIter = ipv4staticRouteBeans.iterator()
		while (ipv4staticRouteBeansIter.hasNext()) {
			ipv4staticRouteBean = ipv4staticRouteBeansIter.next()
			staticRoute = new StaticRoute()
			staticRoute.destinationIp = ipv4staticRouteBean.getDestIp()
			staticRoute.gatewayIp = ipv4staticRouteBean.getGateway()
			staticRoute.maskIp = ipv4staticRouteBean.getMask()
			retVal.put(staticRoute.destinationIp, staticRoute)
		}

		List<Ipv6NewCfgStaticRouteEntry> ipv6staticRouteBeans = connection.readAllBeans('Ipv6NewCfgStaticRouteEntry')
		Iterator<Ipv6NewCfgStaticRouteEntry> ipv6staticRouteBeansIter = ipv6staticRouteBeans.iterator()
		while (ipv6staticRouteBeansIter.hasNext()) {
			ipv6staticRouteBean = ipv6staticRouteBeansIter.next()
			staticRoute = new StaticRoute()
			staticRoute.destinationIp = ipv6staticRouteBean.getDestIp()
			staticRoute.gatewayIp = ipv6staticRouteBean.getGateway()
			staticRoute.maskIp = ipv6staticRouteBean.getMask()
			retVal.put(staticRoute.destinationIp, staticRoute)
		}

		return retVal
	}
}