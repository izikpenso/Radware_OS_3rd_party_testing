package com.radware.vdirect.os.lb.v2.l4

import com.radware.logging.VDirectLogger;
import java.text.Format;
import java.util.Map;
import java.util.Set;
import java.beans.PersistenceDelegate;
import java.util.regex.Matcher
import java.util.regex.Pattern

import org.apache.commons.net.util.SubnetUtils;
import org.springframework.beans.factory.annotation.Autowired;

import groovy.transform.ToString
import groovy.transform.EqualsAndHashCode

import com.google.common.cache.AbstractCache.StatsCounter;
import com.radware.alteon.beans.adc.*;
import com.radware.alteon.api.*;
import com.radware.alteon.sdk.*
import com.radware.alteon.sdk.containers.SoftAdcInfo;
import com.radware.alteon.sdk.impl.resources.wrapped.WrappedAdcService;
import com.radware.alteon.sdk.rpm.*
import com.radware.alteon.workflow.impl.DeviceConnection;
import com.radware.alteon.workflow.impl.WorkflowAdaptor;
import com.radware.alteon.workflow.impl.java.ConfigurationTemplate;
import com.radware.alteon.api.impl.AlteonCliUtils;
import com.radware.alteon.api.impl.template.parameter.ArrayParameterType;
import com.radware.alteon.api.impl.template.parameter.IntegerParameterType;
import com.radware.alteon.cli.CliSession;
import com.radware.beans.IReadableBean;
import com.radware.logging.VDirectLogger;
import com.radware.osjava.nova.command.AggregatesExtension.AddHost;
import com.radware.osjava.nova.model.KeyPair;
import com.radware.vdirect.client.api.IAdcSessionBoundObjectFactory;
import com.radware.vdirect.os.lb.v2.structures.l4.HealthMonitorParams;
import com.radware.vdirect.os.lb.v2.structures.l4.ListenerParams;
import com.radware.vdirect.os.lb.v2.structures.l4.MemberParams;
import com.radware.vdirect.os.lb.v2.structures.l4.RealServerParams;
import com.radware.vdirect.os.lb.v2.structures.l4.SNITLSCertificateParams;
import com.radware.vdirect.os.lb.v2.structures.l4.TLSCertificateParams;
import com.radware.vdirect.os.lb.v2.structures.persistent.CertIntermediate;
import com.radware.vdirect.os.lb.v2.structures.persistent.Stats;
import com.radware.vdirect.os.lb.v2.structures.persistent.StaticRoute;
import com.radware.vdirect.os.lb.v2.structures.persistent.LBVirt;
import com.radware.vdirect.os.lb.v2.structures.persistent.GroupRealServers;
import com.radware.vdirect.os.lb.v2.structures.persistent.RealServer;
import com.radware.alteon.beans.adc.SlbStatEnhVServerEntry;
import com.radware.alteon.beans.adc.IfXEntry;

public class L4SetupUtility {
	
	public static final String DISSOCIATE_HM = "dissociate"
	public static final String ASSOCIATE_HM = "associate"
	public static final String UPDATE_HM = "update"
	public static final String CERTIFICATE_START = "-----BEGIN CERTIFICATE-----"
	public static final String CERTIFICATE_END = "-----END CERTIFICATE-----"
	public static final String TERMINATED_HTTPS = "TERMINATED_HTTPS"
	
	DeviceConnection connection
	WorkflowAdaptor workflow
	VDirectLogger log
	ListenerParams[] listeners
	
	Map<String, ListenerParams> incommingVirts

	PersistencyData persistencyData
	DeviceConfigurator deviceConfigurator
	
	public L4SetupUtility (DeviceConfigurator deviceConfigurator, String service_name, WorkflowAdaptor workflow, VDirectLogger logger) {
		this(deviceConfigurator, service_name, workflow, logger, []);
	}

	public L4SetupUtility (DeviceConfigurator deviceConfigurator, String service_name, WorkflowAdaptor workflow, VDirectLogger logger, ListenerParams[] listeners) {
		this.connection = connection
		this.workflow = workflow
		this.log = logger
		this.listeners = listeners
		
		this.deviceConfigurator = deviceConfigurator;
		Map<String, StaticRoute> static_routes = this.deviceConfigurator.getStaticRoutes();
		this.persistencyData = new PersistencyData(static_routes, workflow)
		
		initialize()
	}
	
	private void initialize () {
		// Initialize incoming VIRTs configuration
		this.incommingVirts = new HashMap<String, ListenerParams>()
		ListenerParams listener
		Iterator<ListenerParams> listenersIter = listeners.iterator()
		while (listenersIter.hasNext()) {
			listener = listenersIter.next()
			incommingVirts.put(getNoDashesUUID(listener.id), listener)
		}		
	}
	
	private String getNoDashesUUID (String uuid) {
		String new_uuid = uuid.replace("-", "")
		return new_uuid
	}

	private String getIntermCaId (String certId, String certTextBody) {
		return certId.substring(0, 24) + String.format("%08x", certTextBody.hashCode())
	}
	
	private String getRealServersGroupId (String virtId) {
		virtId.substring(0, 23) + "virtgrp"
	}

	private String getIntermCaGroupId (String virtId) {
		virtId.substring(0, 23) + "intermca"
	}

	private String getSrvrcertGroupId (String virtId) {
		virtId.substring(0, 23) + "srvrcert"
	}

	public void persistWFPersistentData () {
		this.persistencyData.persistWFPersistentData()
	}
	
	public void clearWFPersistentData () {
		this.persistencyData.clearWFPersistentData()
	}
	
	private Map<String, MemberParams> getListenerMemberParamsMap (ListenerParams listenerParams) {
		Map<String, MemberParams> memberParamsMap = new HashMap<String, MemberParams>()
		MemberParams memberParams;

		if (listenerParams.default_pool == null) {
			return memberParamsMap;
		}
		
		Iterator<MemberParams> memberParamsIter = Arrays.asList(listenerParams.default_pool.members).iterator()
		while(memberParamsIter.hasNext()) {
			memberParams = memberParamsIter.next()
			memberParamsMap.put(getNoDashesUUID(memberParams.id), memberParams)
		}
		return memberParamsMap
	}
	
	private RealServerParams getRealserverParamsFromMemberParams (MemberParams memberParams) {
		RealServerParams realServerParams = new RealServerParams()
		realServerParams.id = memberParams.id
		realServerParams.address = memberParams.address
		realServerParams.protocol_port = memberParams.protocol_port
		realServerParams.weight = memberParams.weight
		realServerParams.admin_state_up = memberParams.admin_state_up
		realServerParams.subnet = memberParams.subnet
		realServerParams.mask = memberParams.mask
		realServerParams.gw = memberParams.gw

		return realServerParams
	}

	private void tearDownVirt(String virtKey) {
		LBVirt lbVirt = persistencyData.getVirtData(virtKey)

		List<String> realServerNames = new ArrayList<String>()
		Iterator<String> realServerNamesIter = persistencyData.getGroupRealServersData(lbVirt.groupName).keySet().iterator()
		while(realServerNamesIter.hasNext()) {
			realServerNames.add(realServerNamesIter.next())
		}
		String[] realServerNamesArray = realServerNames.toArray()

		deviceConfigurator.teardownVirt(
			virtKey, String.valueOf(lbVirt.port),
			realServerNamesArray,
			lbVirt.groupName, getSrvrcertGroupId(virtKey), getIntermCaGroupId(virtKey))
		
		String curDefaultCertId = persistencyData.getVirtDefaultCertId(virtKey)
		String[] curSNICertIds = persistencyData.getVirtSNICertIds(virtKey)
		String[] curIntermCaIds = persistencyData.getVirtIntermCaCertIds(virtKey)
		if (curDefaultCertId != null) {
			deviceConfigurator.removeSrvrCertWithRefCount(curDefaultCertId)
		}
		for (int i = 0; i < curSNICertIds.length; i++) {
			deviceConfigurator.removeSrvrCertWithRefCount(curSNICertIds[i])
		}
		for (int i = 0; i < curIntermCaIds.length; i++) {
			deviceConfigurator.removeIntermCaWithRefCount(curIntermCaIds[i])
		}

		HealthMonitorParams hmParams = persistencyData.getHealthMonitorData(lbVirt.groupName)
		if (hmParams.id != null) {
			deviceConfigurator.configureHM(hmParams, lbVirt.groupName, DISSOCIATE_HM)
		}

		persistencyData.removeVirtData(lbVirt.groupName, virtKey)
		persistencyData.removeVirtDefaultCertId(virtKey)
		persistencyData.removeVirtSNICertIds(virtKey)
		persistencyData.removeVirtIntermCaCertIds(virtKey)
	}	

	public int registerWorkflowOnService (String serviceName) {
		return deviceConfigurator.registerWfOnService(serviceName)
	}

	public int unregisterWorkflowOnService (String serviceName) {
		return deviceConfigurator.unregisterWfOnService(serviceName)
	}

	public void setupVirts () {
		LBVirt lbVirt
		String virtName
		String groupName, srvrcertGroupName, intermcaGroupName
		String port

		Set<String> deletedVirtKeys = persistencyData.getDeletedVirtKeys(incommingVirts.keySet())
		Set<String> newVirtKeys = persistencyData.getNewVirtKeys(incommingVirts.keySet())
		
		Iterator<String> toDeleteVirtsIter = deletedVirtKeys.iterator()
		while (toDeleteVirtsIter.hasNext()) {
			tearDownVirt(toDeleteVirtsIter.next()) 		
		}

		ListenerParams listenerToCreate
		Iterator<String> toCreateVirtsIter = newVirtKeys.iterator()
		while (toCreateVirtsIter.hasNext()) {
			virtName = toCreateVirtsIter.next()
			listenerToCreate = incommingVirts.get(virtName)
			port = String.valueOf(listenerToCreate.protocol_port)

			groupName = getRealServersGroupId(virtName)
				
			deviceConfigurator.configureVirt(
				virtName, groupName,
				port, listenerToCreate.protocol,
				listenerToCreate.default_pool.lb_algorithm,
				listenerToCreate.default_pool.admin_state_up,
				listenerToCreate.default_pool.sessionpersistence.type,
				listenerToCreate.default_pool.sessionpersistence.cookie_name)

			persistencyData.addNewVirtData(virtName, port, groupName)
		}
	}
	
	private TLSCertificateParams getTLSCertificateFromSNICertificate (SNITLSCertificateParams sniCert) {
		TLSCertificateParams tlsCert = new TLSCertificateParams()
		tlsCert.id = sniCert.id
		tlsCert.certificate = sniCert.certificate
		tlsCert.intermediates = sniCert.intermediates
		tlsCert.private_key = sniCert.private_key
		tlsCert.passphrase = sniCert.passphrase
		return tlsCert
	}
	
	private Map<String, String> getCertIntermCaList (String certId, String intermediates) {
		Map<String, String> map = new LinkedHashMap<String, String>()
		String certText, certTextBody

		if (intermediates == null) {
			return map
		}
		int startIndex, endIndex = 0
		while (startIndex >= 0) {
			startIndex = intermediates.indexOf(CERTIFICATE_START, startIndex)
			if (startIndex < 0) {
				continue;
			}
			endIndex = intermediates.indexOf(CERTIFICATE_END, startIndex)
			if (endIndex < 0) {
				continue;
			}
			
			certText = intermediates.substring(startIndex, endIndex + CERTIFICATE_END.length())
			certTextBody = intermediates.substring(startIndex + CERTIFICATE_START.length(), endIndex - 1)
			map.put(getIntermCaId(certId, certTextBody),certText)

			startIndex = endIndex + CERTIFICATE_END.length()
		}
		
		return map
	}

	private Map<String, String> getVirtIntermCaMap (
			TLSCertificateParams defCertParams,
			SNITLSCertificateParams[] sniCertsParams) {

		String certId = getNoDashesUUID(defCertParams.id)
		Map<String, String> map = getCertIntermCaList(certId, defCertParams.intermediates)
		
		SNITLSCertificateParams certParams
		Iterator<SNITLSCertificateParams> certParamsIter = sniCertsParams.iterator()
		while (certParamsIter.hasNext()) {
			certParams = certParamsIter.next()
			map.putAll(getCertIntermCaList(certId, certParams.intermediates))
		}
		
		return map
	}
	
	public void setupVirtsTLS () {

		ListenerParams listener
		String protocole, port, srvrcertGroupName, intermcaGroupName
		
		String curDefaultCertId, newDefaultCertId
		TLSCertificateParams newDefaultCertParams
		
		String[] curSNICertIds, newSNICertIds
		SNITLSCertificateParams[] newSNICertsParams
		
		String[] curIntermCaIds, newIntermCaIds
		
		Iterator<String> virtsKeyIter = incommingVirts.keySet().iterator()
		while (virtsKeyIter.hasNext()) {
			String virtKey = virtsKeyIter.next()
			listener = incommingVirts.get(virtKey)
			protocole = listener.protocol
			if (!protocole.equals(TERMINATED_HTTPS)) {
				continue;
			}
			port = String.valueOf(listener.protocol_port)
			srvrcertGroupName = getSrvrcertGroupId(virtKey)
			intermcaGroupName = getIntermCaGroupId(virtKey)
			
			// Get current and new default and SNI certificates info
			curDefaultCertId = persistencyData.getVirtDefaultCertId(virtKey)
			newDefaultCertParams = incommingVirts.get(virtKey).default_tls_certificate
			newDefaultCertParams.id = getNoDashesUUID(newDefaultCertParams.id)
			newDefaultCertId = newDefaultCertParams.id
			
			curSNICertIds = persistencyData.getVirtSNICertIds(virtKey)
			newSNICertsParams = incommingVirts.get(virtKey).sni_tls_certificates
			newSNICertIds = new String[newSNICertsParams.length]
			
			for (int i = 0; i < newSNICertsParams.length; i++) {
				newSNICertsParams[i].id = getNoDashesUUID(newSNICertsParams[i].id)
				newSNICertIds[i]= newSNICertsParams[i].id
			}
			
			curIntermCaIds = persistencyData.getVirtIntermCaCertIds(virtKey)
			Map<String, String> newIntermCaMap = getVirtIntermCaMap (newDefaultCertParams, newSNICertsParams)
			newIntermCaIds = newIntermCaMap.keySet().toArray()
			
			// Handle default certificate reference count and import new one if needed
			if (!curDefaultCertId.equals(newDefaultCertParams.id)) {
				deviceConfigurator.addSrvrCertWithRefCount(newDefaultCertParams)
				persistencyData.addVirtDefaultCertId(virtKey, newDefaultCertParams.id)
			}

			// Handle SNI certificates and import new ones when needed
			if (!Arrays.equals(curSNICertIds, newSNICertIds)) {
				SNITLSCertificateParams sniCertParams
				Iterator<SNITLSCertificateParams> sniCertsIter = newSNICertsParams.iterator()
				while (sniCertsIter.hasNext()) {
					sniCertParams = sniCertsIter.next()
					deviceConfigurator.addSrvrCertWithRefCount(getTLSCertificateFromSNICertificate(sniCertParams))
				}
				persistencyData.addVirtSNICertIds(virtKey, newSNICertIds)
			}
			
			// Handle intermediate certificates and import new ones when needed
			if (!Arrays.equals(curIntermCaIds, newIntermCaIds)) {
				CertIntermediate intermCa
				Iterator<String> intermCaIter = newIntermCaMap.keySet().iterator()
				while (intermCaIter.hasNext()) {
					intermCa = new CertIntermediate()
					intermCa.id = intermCaIter.next()
					intermCa.cert = newIntermCaMap.get(intermCa.id)
					deviceConfigurator.addIntermCaWithRefCount(intermCa)
				}
				persistencyData.addVirtIntermCaCertIds(virtKey, newIntermCaIds)
			}
			
			deviceConfigurator.configureSrvrCertGroupDefault(virtKey, port, srvrcertGroupName, newDefaultCertId, curDefaultCertId)
			deviceConfigurator.configureSrvrCertGroupSNI(virtKey, port, srvrcertGroupName, curSNICertIds, newSNICertIds)
			if (newIntermCaIds.size() > 0) {
				deviceConfigurator.configureIntermCaGroup(virtKey, port, intermcaGroupName, curIntermCaIds, newIntermCaIds)
			}
			
			if (curDefaultCertId != null) {
				deviceConfigurator.removeSrvrCertWithRefCount(curDefaultCertId)
			}
			for (int i = 0; i < curSNICertIds.length; i++) {
				deviceConfigurator.removeSrvrCertWithRefCount(getTLSCertificateFromSNICertificate(curSNICertIds[i]))
			}
			for (int i = 0; i < curIntermCaIds.length; i++) {
				deviceConfigurator.removeIntermCaWithRefCount(curIntermCaIds[i])
			}
		}
	}
	
	public void setupRealServers () {
	
		Map<String, RealServer> realServersMap
		Map<String, MemberParams> memberParamsMap
		
		LBVirt lbVirt
		GroupRealServers groupRealServers
		RealServer[] realServers
		
		ListenerParams listener
		String virtName
		String groupName
		
		Iterator<String> serviceNameIter = incommingVirts.keySet().iterator()
		while (serviceNameIter.hasNext()) {
			virtName = serviceNameIter.next()
			listener = incommingVirts.get(virtName)
			lbVirt = persistencyData.getVirtData(virtName)
			groupName = lbVirt.groupName
			
			realServersMap = persistencyData.getGroupRealServersData(groupName)
			memberParamsMap = getListenerMemberParamsMap(listener)
			
			Set<String> newServers = persistencyData.getNewGroupRealServersKeys(groupName, memberParamsMap.keySet())
			Set<String> updatedServers = persistencyData.getUpdatedGroupRealServersKeys(groupName, memberParamsMap.keySet())
			Set<String> deletedServers = persistencyData.getDeletedGroupRealServersKeys(groupName, memberParamsMap.keySet())
			
			List<RealServerParams> newRealServers = new ArrayList<RealServerParams>()
			List<RealServerParams> updatedRealServers = new ArrayList<RealServerParams>()
			List<String> deletedRealServersNames = new ArrayList<String>()
			
			MemberParams memberParams
			RealServerParams realServerParams
			String realServerKey
			
			Iterator<String> newServersIter = newServers.iterator()
			while (newServersIter.hasNext()) {
				memberParams = memberParamsMap.get(newServersIter.next())
				realServerParams = getRealserverParamsFromMemberParams (memberParams)
				realServerParams.name = getNoDashesUUID(memberParams.id)
				persistencyData.addNewRealServerData(groupName, realServerParams)
				newRealServers.add(realServerParams)
			}

			Iterator<String> updatesServersIter = updatedServers.iterator()
			while (updatesServersIter.hasNext()) {
				realServerKey = updatesServersIter.next()
				memberParams = memberParamsMap.get(realServerKey)
				realServerParams = getRealserverParamsFromMemberParams (memberParams)
				realServerParams.name = getNoDashesUUID(memberParams.id)
				updatedRealServers.add(realServerParams)
			}

			Iterator<String> deletedServersIter = deletedServers.iterator()
			while (deletedServersIter.hasNext()) {
				realServerKey = deletedServersIter.next()
				
				deletedRealServersNames.add(realServersMap.get(realServerKey).name)
				persistencyData.removeRealServerData (groupName, realServerKey)
			}

			deviceConfigurator.configureGroup(groupName, listener.default_pool.admin_state_up,
					   newRealServers.toArray(new RealServerParams[newRealServers.size()]), 
					   updatedRealServers.toArray(new RealServerParams[updatedRealServers.size()]), 
					   deletedRealServersNames.toArray(new String[deletedRealServersNames.size()]))
		}
	}
							 
	public void setupHealthMonitors () {
	
		ListenerParams listener
		String virtName
		LBVirt lbVirt
		String groupName
		HealthMonitorParams hmParams
		HealthMonitorParams prevHmParams
		String hmId
		String prevHmId
		
		Iterator<String> virtsIter = incommingVirts.keySet().iterator()
		while (virtsIter.hasNext()) {
			virtName = virtsIter.next()
			listener = incommingVirts.get(virtName)
			lbVirt = persistencyData.getVirtData(virtName)
			groupName = lbVirt.groupName
			
			hmParams = listener.default_pool.healthmonitor
			if (hmParams.id.equals("none")) {
				hmParams.id = null
			}
			else {
				hmParams.id = getNoDashesUUID(hmParams.id)
			}
			prevHmParams = persistencyData.setHealthMonitorData(groupName, hmParams)
			
			hmId = (hmParams == null) ? null :  hmParams.id;
			prevHmId = (prevHmParams == null) ? null :  prevHmParams.id;

			if (hmId != prevHmId) {
				if (prevHmId != null) {
					deviceConfigurator.configureHM(prevHmParams, groupName, DISSOCIATE_HM)
				}
				if (hmId != null) {
					deviceConfigurator.configureHM(hmParams, groupName, ASSOCIATE_HM)
				}
			}
			else if (hmId != null) {
				deviceConfigurator.configureHM(hmParams, groupName, UPDATE_HM)
			}
		}
	}

	public void setupStaticRoutes () {

		StaticRoute staticRoute
		Set<StaticRoute> newStaticRoutes = new HashSet<StaticRoute>()
		
		ListenerParams listener
		String virtName
		Map<String, MemberParams> memberParamsMap
		
		Iterator<String> virtIter = incommingVirts.keySet().iterator()
		while (virtIter.hasNext()) {
			virtName = virtIter.next()
			listener = incommingVirts.get(virtName)
			memberParamsMap = getListenerMemberParamsMap(listener)
			MemberParams memberParams

			Iterator<MemberParams> membersIter = memberParamsMap.values().iterator()
			while (membersIter.hasNext()) {
				memberParams = membersIter.next()
				if (persistencyData.addNewStaticRouteData(memberParams)) {
					newStaticRoutes.add(persistencyData.getStaticRouteData(memberParams.subnet))
				}
			}
		}
		
		StaticRoute[] staticRoutesArray = newStaticRoutes.toArray()
		if (staticRoutesArray.length > 0) {
			deviceConfigurator.configureStaticRoutes(staticRoutesArray)
		}
	}
	
	public void teardown () {
		Iterator<String> toDeleteVirtsIter = persistencyData.getVirtKeys().iterator()
		while (toDeleteVirtsIter.hasNext()) {
			tearDownVirt(toDeleteVirtsIter.next()) 		
		}
	}
}