package com.radware.vdirect.os.lb.v2.l4

import com.radware.logging.VDirectLogger;
import java.text.Format;
import java.util.Map;
import java.util.Set;
import java.beans.PersistenceDelegate;
import java.util.regex.Matcher
import java.util.regex.Pattern

import org.apache.commons.net.util.SubnetUtils;
import org.springframework.beans.factory.annotation.Autowired;

import groovy.transform.ToString
import groovy.transform.EqualsAndHashCode

import com.google.common.cache.AbstractCache.StatsCounter;
import com.radware.alteon.beans.adc.*;
import com.radware.alteon.api.*;
import com.radware.alteon.sdk.*
import com.radware.alteon.sdk.containers.SoftAdcInfo;
import com.radware.alteon.sdk.impl.resources.wrapped.WrappedAdcService;
import com.radware.alteon.sdk.rpm.*
import com.radware.alteon.workflow.impl.DeviceConnection;
import com.radware.alteon.workflow.impl.WorkflowAdaptor;
import com.radware.alteon.workflow.impl.java.ConfigurationTemplate;
import com.radware.alteon.api.impl.AlteonCliUtils;
import com.radware.alteon.api.impl.template.parameter.ArrayParameterType;
import com.radware.alteon.api.impl.template.parameter.IntegerParameterType;
import com.radware.alteon.cli.CliSession;
import com.radware.beans.IReadableBean;
import com.radware.logging.VDirectLogger;
import com.radware.vdirect.client.api.IAdcSessionBoundObjectFactory;
import com.radware.vdirect.os.lb.v2.structures.l4.HealthMonitorParams;
import com.radware.vdirect.os.lb.v2.structures.l4.L7PolicyParams;
import com.radware.vdirect.os.lb.v2.structures.l4.L7RuleParams;
import com.radware.vdirect.os.lb.v2.structures.l4.ListenerParams;
import com.radware.vdirect.os.lb.v2.structures.l4.PoolParams;
import com.radware.vdirect.os.lb.v2.structures.l4.MemberParams;
import com.radware.vdirect.os.lb.v2.structures.l4.RealServerParams;
import com.radware.vdirect.os.lb.v2.structures.l4.SNITLSCertificateParams;
import com.radware.vdirect.os.lb.v2.structures.l4.TLSCertificateParams;
import com.radware.vdirect.os.lb.v2.structures.persistent.CertIntermediate;
import com.radware.vdirect.os.lb.v2.structures.persistent.Stats;
import com.radware.vdirect.os.lb.v2.structures.persistent.StaticRoute;
import com.radware.vdirect.os.lb.v2.structures.persistent.LBVirt;
import com.radware.vdirect.os.lb.v2.structures.persistent.GroupRealServers;
import com.radware.vdirect.os.lb.v2.structures.persistent.RealServer;
import com.radware.alteon.beans.adc.SlbStatEnhVServerEntry;
import com.radware.alteon.beans.adc.IfXEntry;

public class L4SetupUtility {
	
	public static final String DISSOCIATE_HM = "dissociate"
	public static final String ASSOCIATE_HM = "associate"
	public static final String UPDATE_HM = "update"
	public static final String CERTIFICATE_START = "-----BEGIN CERTIFICATE-----"
	public static final String CERTIFICATE_END = "-----END CERTIFICATE-----"
	public static final String TERMINATED_HTTPS = "TERMINATED_HTTPS"
	
	public static final String REDIRECT_TO_POOL_ACTION_TYPE = "REDIRECT_TO_POOL"
	
	DeviceConnection connection
	WorkflowAdaptor workflow
	VDirectLogger log
	ListenerParams[] listeners
	PoolParams[] pools
	
	Map<String, ListenerParams> incommingVirts
	Map<String, PoolParams> incommingGroups
	
	PersistencyData persistencyData
	DeviceConfigurator deviceConfigurator
	
	public L4SetupUtility (DeviceConfigurator deviceConfigurator, String service_name, WorkflowAdaptor workflow, VDirectLogger logger) {
		this(deviceConfigurator, service_name, workflow, logger, [], []);
	}

	public L4SetupUtility (DeviceConfigurator deviceConfigurator, String service_name, WorkflowAdaptor workflow, VDirectLogger logger,
		             	   ListenerParams[] listeners, PoolParams[] pools) {
		this.connection = connection
		this.workflow = workflow
		this.log = logger
		this.listeners = listeners
		this.pools = pools
		
		this.deviceConfigurator = deviceConfigurator;
		Map<String, StaticRoute> static_routes = this.deviceConfigurator.getStaticRoutes();
		this.persistencyData = new PersistencyData(static_routes, workflow)
		
		initialize()
	}
	
	private void initialize () {
		this.incommingVirts = new HashMap<String, ListenerParams>()
		ListenerParams listener
		Iterator<ListenerParams> listenersIter = listeners.iterator()
		while (listenersIter.hasNext()) {
			listener = listenersIter.next()
			incommingVirts.put(getNoDashesUUID(listener.id), listener)
		}		

		this.incommingGroups = new HashMap<String, PoolParams>()
		PoolParams pool
		Iterator<PoolParams> poolsIter = pools.iterator()
		while (poolsIter.hasNext()) {
			pool = poolsIter.next()
			incommingGroups.put(getNoDashesUUID(pool.id), pool)
		}		
	}
	
	public int registerWorkflowOnService (String serviceName) {
		return deviceConfigurator.registerWfOnService(serviceName)
	}

	public int unregisterWorkflowOnService (String serviceName) {
		return deviceConfigurator.unregisterWfOnService(serviceName)
	}

	public void persistWFPersistentData () {
		this.persistencyData.persistWFPersistentData()
	}
	
	public void clearWFPersistentData () {
		this.persistencyData.clearWFPersistentData()
	}

	private String getNoDashesUUID (String uuid) {
		if (uuid != null && !uuid.equals("None")) {
			return uuid.replace("-", "")
		}
		return uuid
	}

	private String getIntermCaId (String certId, String certTextBody) {
		return certId.substring(0, 24) + String.format("%08x", certTextBody.hashCode())
	}
	
	private String getRealServersGroupId (String virtId) {
		virtId.substring(0, 23) + "virtgrp"
	}

	private String getIntermCaGroupId (String virtId) {
		virtId.substring(0, 23) + "intermca"
	}

	private String getSrvrcertGroupId (String virtId) {
		virtId.substring(0, 23) + "srvrcert"
	}

	
	private Map<String, MemberParams> getGroupMemberParamsMap (PoolParams poolParams) {
		Map<String, MemberParams> memberParamsMap = new HashMap<String, MemberParams>()
		MemberParams memberParams;

		Iterator<MemberParams> memberParamsIter = Arrays.asList(poolParams.members).iterator()
		while(memberParamsIter.hasNext()) {
			memberParams = memberParamsIter.next()
			memberParamsMap.put(getNoDashesUUID(memberParams.id), memberParams)
		}
		return memberParamsMap
	}

	private RealServerParams getRealserverParamsFromMemberParams (MemberParams memberParams) {
		RealServerParams realServerParams = new RealServerParams()
		realServerParams.id = memberParams.id
		realServerParams.name = getNoDashesUUID(memberParams.id)
		realServerParams.address = memberParams.address
		realServerParams.protocol_port = memberParams.protocol_port
		realServerParams.weight = memberParams.weight
		realServerParams.admin_state_up = memberParams.admin_state_up
		realServerParams.subnet = memberParams.subnet
		realServerParams.mask = memberParams.mask
		realServerParams.gw = memberParams.gw

		return realServerParams
	}

	public void setupVirts () {
		LBVirt lbVirt
		ListenerParams listener
		String virtName
		String groupName, srvrcertGroupName, intermcaGroupName
		String port
		boolean enabled

		Set<String> deletedVirtKeys = persistencyData.getDeletedVirtKeys(incommingVirts.keySet())
		Set<String> newVirtKeys = persistencyData.getNewVirtKeys(incommingVirts.keySet())
		Set<String> updatedVirtKeys = persistencyData.getUpdatedVirtKeys(incommingVirts.keySet())
		
		Iterator<String> toDeleteVirtsIter = deletedVirtKeys.iterator()
		while (toDeleteVirtsIter.hasNext()) {
			tearDownVirt(toDeleteVirtsIter.next(), workflow['appwall_license'])
		}

		Iterator<String> toUpdateVirtsIter = updatedVirtKeys.iterator()
		while (toUpdateVirtsIter.hasNext()) {
			virtName = toUpdateVirtsIter.next()
			listener = incommingVirts.get(virtName)
			port = String.valueOf(listener.protocol_port)
			enabled = listener.admin_state_up
			if (!workflow['admin_state_up']) {
				enabled = false
			}

			groupName = getNoDashesUUID(listener.default_pool.id)
				
			deviceConfigurator.configureVirt(
				virtName, groupName, enabled,
				port, listener.protocol,
				listener.default_pool.sessionpersistence.type,
				listener.default_pool.sessionpersistence.cookie_name,
				workflow['appwall_license'])
		}

		Iterator<String> toCreateVirtsIter = newVirtKeys.iterator()
		while (toCreateVirtsIter.hasNext()) {
			virtName = toCreateVirtsIter.next()
			listener = incommingVirts.get(virtName)
			port = String.valueOf(listener.protocol_port)
			enabled = listener.admin_state_up
			if (!workflow['admin_state_up']) {
				enabled = false
			}

			groupName = getNoDashesUUID(listener.default_pool.id)
				
			deviceConfigurator.configureVirt(
				virtName, groupName, enabled,
				port, listener.protocol,
				listener.default_pool.sessionpersistence.type,
				listener.default_pool.sessionpersistence.cookie_name,
				workflow['appwall_license'])

			persistencyData.addNewVirtData(virtName, port, groupName)
		}
	}
	
	private TLSCertificateParams getTLSCertificateFromSNICertificate (SNITLSCertificateParams sniCert) {
		TLSCertificateParams tlsCert = new TLSCertificateParams()
		tlsCert.id = sniCert.id
		tlsCert.certificate = sniCert.certificate
		tlsCert.intermediates = sniCert.intermediates
		tlsCert.private_key = sniCert.private_key
		tlsCert.passphrase = sniCert.passphrase
		return tlsCert
	}
	
	private Map<String, String> getCertIntermCaList (String certId, String intermediates) {
		Map<String, String> map = new LinkedHashMap<String, String>()
		String certText, certTextBody

		if (intermediates == null) {
			return map
		}
		int startIndex, endIndex = 0
		while (startIndex >= 0) {
			startIndex = intermediates.indexOf(CERTIFICATE_START, startIndex)
			if (startIndex < 0) {
				continue;
			}
			endIndex = intermediates.indexOf(CERTIFICATE_END, startIndex)
			if (endIndex < 0) {
				continue;
			}
			
			certText = intermediates.substring(startIndex, endIndex + CERTIFICATE_END.length())
			certTextBody = intermediates.substring(startIndex + CERTIFICATE_START.length(), endIndex - 1)
			map.put(getIntermCaId(certId, certTextBody),certText)

			startIndex = endIndex + CERTIFICATE_END.length()
		}
		
		return map
	}

	private Map<String, String> getVirtIntermCaMap (
			TLSCertificateParams defCertParams,
			SNITLSCertificateParams[] sniCertsParams) {

		String certId = getNoDashesUUID(defCertParams.id)
		Map<String, String> map = getCertIntermCaList(certId, defCertParams.intermediates)
		
		SNITLSCertificateParams certParams
		Iterator<SNITLSCertificateParams> certParamsIter = sniCertsParams.iterator()
		while (certParamsIter.hasNext()) {
			certParams = certParamsIter.next()
			map.putAll(getCertIntermCaList(certId, certParams.intermediates))
		}
		
		return map
	}
	
	public void setupVirtsTLS () {

		ListenerParams listener
		String protocole, port, srvrcertGroupName, intermcaGroupName
		
		String curDefaultCertId, newDefaultCertId
		TLSCertificateParams newDefaultCertParams
		
		String[] curSNICertIds, newSNICertIds
		SNITLSCertificateParams[] newSNICertsParams
		
		String[] curIntermCaIds, newIntermCaIds
		
		Iterator<String> virtsKeyIter = incommingVirts.keySet().iterator()
		while (virtsKeyIter.hasNext()) {
			String virtKey = virtsKeyIter.next()
			listener = incommingVirts.get(virtKey)
			protocole = listener.protocol
			if (!protocole.equals(TERMINATED_HTTPS)) {
				continue;
			}
			port = String.valueOf(listener.protocol_port)
			srvrcertGroupName = getSrvrcertGroupId(virtKey)
			intermcaGroupName = getIntermCaGroupId(virtKey)
			
			// Get current and new default and SNI certificates info
			curDefaultCertId = persistencyData.getVirtDefaultCertId(virtKey)
			newDefaultCertParams = incommingVirts.get(virtKey).default_tls_certificate
			newDefaultCertParams.id = getNoDashesUUID(newDefaultCertParams.id)
			newDefaultCertId = newDefaultCertParams.id
			
			curSNICertIds = persistencyData.getVirtSNICertIds(virtKey)
			newSNICertsParams = incommingVirts.get(virtKey).sni_tls_certificates
			newSNICertIds = new String[newSNICertsParams.length]
			
			for (int i = 0; i < newSNICertsParams.length; i++) {
				newSNICertsParams[i].id = getNoDashesUUID(newSNICertsParams[i].id)
				newSNICertIds[i]= newSNICertsParams[i].id
			}
			
			curIntermCaIds = persistencyData.getVirtIntermCaCertIds(virtKey)
			Map<String, String> newIntermCaMap = getVirtIntermCaMap (newDefaultCertParams, newSNICertsParams)
			newIntermCaIds = newIntermCaMap.keySet().toArray()
			
			// Handle default certificate reference count and import new one if needed
			if (!curDefaultCertId.equals(newDefaultCertParams.id)) {
				deviceConfigurator.addSrvrCertWithRefCount(newDefaultCertParams)
				if (curDefaultCertId != null) {
					deviceConfigurator.removeSrvrCertWithRefCount(curDefaultCertId)
				}
				
				deviceConfigurator.configureSrvrCertGroupDefault(virtKey, port, srvrcertGroupName, newDefaultCertId, curDefaultCertId)
				
				persistencyData.addVirtDefaultCertId(virtKey, newDefaultCertParams.id)
			}

			// Handle SNI certificates and import new ones when needed
			if (!Arrays.equals(curSNICertIds, newSNICertIds)) {
				SNITLSCertificateParams sniCertParams
				Iterator<SNITLSCertificateParams> sniCertsIter = newSNICertsParams.iterator()
				while (sniCertsIter.hasNext()) {
					sniCertParams = sniCertsIter.next()
					deviceConfigurator.addSrvrCertWithRefCount(getTLSCertificateFromSNICertificate(sniCertParams))
				}
				
				for (int i = 0; i < curSNICertIds.length; i++) {
					deviceConfigurator.removeSrvrCertWithRefCount(curSNICertIds[i])
				}
				
				deviceConfigurator.configureSrvrCertGroupSNI(virtKey, port, srvrcertGroupName, curSNICertIds, newSNICertIds)
				
				persistencyData.addVirtSNICertIds(virtKey, newSNICertIds)
			}
			
			// Handle intermediate certificates and import new ones when needed
			if (!Arrays.equals(curIntermCaIds, newIntermCaIds)) {
				CertIntermediate intermCa
				Iterator<String> intermCaIter = newIntermCaMap.keySet().iterator()
				while (intermCaIter.hasNext()) {
					intermCa = new CertIntermediate()
					intermCa.id = intermCaIter.next()
					intermCa.cert = newIntermCaMap.get(intermCa.id)
					deviceConfigurator.addIntermCaWithRefCount(intermCa)
				}
				
				for (int i = 0; i < curIntermCaIds.length; i++) {
					deviceConfigurator.removeIntermCaWithRefCount(curIntermCaIds[i])
				}
				
				deviceConfigurator.configureIntermCaGroup(virtKey, port, intermcaGroupName, curIntermCaIds, newIntermCaIds)
				
				persistencyData.addVirtIntermCaCertIds(virtKey, newIntermCaIds)
			}
		}
	}
	
	public void setupVirtsL7 () {
		
		Map<String, L7PolicyParams> currentL7PoliciesMap
		
		LBVirt lbVirt
		String L7PolicyKey
		L7PolicyParams l7Policy
		L7PolicyParams persistentL7Policy
		L7PolicyParams[] l7Policies
		L7RuleParams[] l7Rules
		L7RuleParams l7Rule
		
		ListenerParams listener
		String virtName
		
		Iterator<String> serviceNameIter = incommingVirts.keySet().iterator()
		while (serviceNameIter.hasNext()) {
			virtName = serviceNameIter.next()
			listener = incommingVirts.get(virtName)
			lbVirt = persistencyData.getVirtData(virtName)
			
			Map<String, L7PolicyParams> incommingL7PoliciesMap = new HashMap<String, L7PolicyParams>()
			currentL7PoliciesMap = persistencyData.getL7PoliciesData(virtName)
			Iterator<L7PolicyParams> l7PolicyParamsIter = Arrays.asList(listener.l7_policies).iterator()
			while(l7PolicyParamsIter.hasNext()) {
				l7Policy = l7PolicyParamsIter.next()
				incommingL7PoliciesMap.put(getNoDashesUUID(l7Policy.id), l7Policy)
			}
			
			Set<String> incommingPoliciesNames;
			if (incommingL7PoliciesMap.isEmpty()) {
				incommingPoliciesNames = new HashSet<String>();
			}
			else {
				incommingPoliciesNames = incommingL7PoliciesMap.keySet()
			}
			
			Set<String> newPoliciesNames = persistencyData.getNewL7PoliciesKeys(virtName, incommingPoliciesNames)
			Set<String> updatedPoliciesNames = persistencyData.getUpdatedL7PoliciesKeys(virtName, incommingPoliciesNames)
			Set<String> deletedPoliciesNames = persistencyData.getDeletedL7PoliciesKeys(virtName, incommingPoliciesNames)
			
			Iterator<String> deletedPoliciesNamesIter = deletedPoliciesNames.iterator()
			while (deletedPoliciesNamesIter.hasNext()) {
				L7PolicyKey = deletedPoliciesNamesIter.next()
				persistentL7Policy = persistencyData.getL7PolicyData(virtName, getNoDashesUUID(L7PolicyKey))
				persistencyData.removeL7PolicyData (virtName, getNoDashesUUID(L7PolicyKey))
				
				deviceConfigurator.deleteL7Policy(virtName, lbVirt.port, L7PolicyKey,
					persistentL7Policy.position)
			}

			Iterator<String> updatesPoliciesNamesIter = updatedPoliciesNames.iterator()
			while (updatesPoliciesNamesIter.hasNext()) {
				L7PolicyKey = updatesPoliciesNamesIter.next()
				l7Policy = incommingL7PoliciesMap.get(L7PolicyKey)
				l7Policy.id = getNoDashesUUID(l7Policy.id)
				l7Policy.redirect_pool_id = getNoDashesUUID(l7Policy.redirect_pool_id)
				persistentL7Policy = persistencyData.getL7PolicyData(virtName, l7Policy.id)
				persistencyData.addNewL7PolicyData(virtName, l7Policy)
				
				l7Rules = l7Policy.rules
				List<L7RuleParams> newL7Rules = new ArrayList<L7RuleParams>()
				Iterator<L7RuleParams> l7RuleParamsIter = Arrays.asList(l7Rules).iterator()
				while(l7RuleParamsIter.hasNext()) {
					l7Rule = l7RuleParamsIter.next()
					l7Rule.id = getNoDashesUUID(l7Rule.id)
					newL7Rules.add(l7Rule)
				}
				l7Policy.rules = newL7Rules.toArray(new L7RuleParams[newL7Rules.size()])
				
				deviceConfigurator.updateL7Policy(virtName, lbVirt.port, l7Policy, persistentL7Policy.position)
			}

			Iterator<String> newPoliciesNamesIter = newPoliciesNames.iterator()
			while (newPoliciesNamesIter.hasNext()) {
				l7Policy = incommingL7PoliciesMap.get(newPoliciesNamesIter.next())
				l7Policy.id = getNoDashesUUID(l7Policy.id)
				l7Policy.redirect_pool_id = getNoDashesUUID(l7Policy.redirect_pool_id)
				persistencyData.addNewL7PolicyData(virtName, l7Policy)
				
				List<L7RuleParams> newL7Rules = new ArrayList<L7RuleParams>()
				String L7RuleKey
				l7Rules = l7Policy.rules
				
				Iterator<L7RuleParams> newRulesIter = l7Rules.iterator()
				while (newRulesIter.hasNext()) {
					l7Rule = newRulesIter.next()
					l7Rule.id = getNoDashesUUID(l7Rule.id)
					newL7Rules.add(l7Rule)
				}
				l7Policy.rules = newL7Rules.toArray(new L7RuleParams[newL7Rules.size()])
				
				deviceConfigurator.createL7Policy(virtName, lbVirt.port, l7Policy)
			}
		}
	}
	
	public void setupGroups () {
	
		Map<String, MemberParams> memberParamsMap
		
		String groupName
		String memberName
		PoolParams groupParams
		MemberParams memberParams
		RealServerParams realServerParams
		
		// Get names sets of new/deleted/updated groups
		Set<String> newGroups = persistencyData.getNewGroups(incommingGroups.keySet())
		Set<String> updatedGroups = persistencyData.getUpdatedGroups(incommingGroups.keySet())
		Set<String> deletedGroups = persistencyData.getDeletedGroups(incommingGroups.keySet())

		// Handle new groups. Add each group with its real servers
		Iterator<String> groupNameIter = newGroups.iterator()
		while (groupNameIter.hasNext()) {
			groupName = groupNameIter.next()
			groupParams = incommingGroups.get(groupName)

			persistencyData.addGroup(groupName)
			
			List<RealServerParams> newRealServers = new ArrayList<RealServerParams>()

			memberParamsMap = getGroupMemberParamsMap(groupParams)
			Iterator<String> memberNameIter = memberParamsMap.keySet().iterator()
			while (memberNameIter.hasNext()) {
				memberName = memberNameIter.next()
				memberParams = memberParamsMap.get(memberName)
				realServerParams = getRealserverParamsFromMemberParams (memberParams)
				
				newRealServers.add(realServerParams)
				persistencyData.addRealServer(groupName, realServerParams)
			}
			
			deviceConfigurator.configureGroup(groupName,
				groupParams.protocol, groupParams.lb_algorithm,
				groupParams.admin_state_up, false,
				newRealServers.toArray(new RealServerParams[newRealServers.size()]),
				new RealServerParams[0], new String[0])
		}

		// Handle updated groups. Update each group with its new/updated/deleted real servers
		groupNameIter = updatedGroups.iterator()
		while (groupNameIter.hasNext()) {
			groupName = groupNameIter.next()
			groupParams = incommingGroups.get(groupName)
			
			List<RealServerParams> newRealServers = new ArrayList<RealServerParams>()
			List<RealServerParams> updatedRealServers = new ArrayList<RealServerParams>()
			List<String> deletedRealServerNames = new ArrayList<String>()

			memberParamsMap = getGroupMemberParamsMap(groupParams)
			
			Set<String> newServers = persistencyData.getNewRealServers(groupName, memberParamsMap.keySet())
			Set<String> updatedServers = persistencyData.getUpdatedRealServers(groupName, memberParamsMap.keySet())
			Set<String> deletedServers = persistencyData.getDeletedRealServers(groupName, memberParamsMap.keySet())

			Iterator<String> serverNameIter = newServers.iterator()
			while (serverNameIter.hasNext()) {
				memberName = serverNameIter.next()
				memberParams = memberParamsMap.get(memberName)
				realServerParams = getRealserverParamsFromMemberParams (memberParams)

				newRealServers.add(realServerParams)
				persistencyData.addRealServer(groupName, realServerParams)
			}

			serverNameIter = updatedServers.iterator()
			while (serverNameIter.hasNext()) {
				memberName = serverNameIter.next()
				memberParams = memberParamsMap.get(memberName)
				realServerParams = getRealserverParamsFromMemberParams (memberParams)
				
				updatedRealServers.add(realServerParams)
			}

			serverNameIter = deletedServers.iterator()
			while (serverNameIter.hasNext()) {
				memberName = serverNameIter.next()
				
				deletedRealServerNames.add(getNoDashesUUID(memberName))
				persistencyData.removeRealServer (groupName, getNoDashesUUID(memberName))
			}

			deviceConfigurator.configureGroup(groupName,
				groupParams.protocol, groupParams.lb_algorithm,
				groupParams.admin_state_up, false,
				newRealServers.toArray(new RealServerParams[newRealServers.size()]), 
				updatedRealServers.toArray(new RealServerParams[updatedRealServers.size()]), 
				deletedRealServerNames.toArray(new String[deletedRealServerNames.size()]))
		}

		// Handle deleted groups. Delete each group with its real servers
		groupNameIter = deletedGroups.iterator()
		while (groupNameIter.hasNext()) {
			groupName = groupNameIter.next()
			
			Map<String, RealServer> realServersMap = persistencyData.getRealServers(groupName)
			List<String> deletedRealServerNames = new ArrayList<String>()
			deletedRealServerNames.addAll(realServersMap.keySet())

			HealthMonitorParams hmParams = persistencyData.getHealthMonitorData(groupName)
			if (hmParams != null) {
				deviceConfigurator.configureHM(hmParams, groupName, DISSOCIATE_HM)
				persistencyData.removeHealthMonitorData(groupName)
			}
			
			deviceConfigurator.configureGroup(groupName,
				"", "",
				false, true,
				new RealServerParams[0], new RealServerParams[0],
				deletedRealServerNames.toArray(new String[deletedRealServerNames.size()]))
			persistencyData.removeGroup(groupName)
		}
	}
						 
	public void setupHealthMonitors () {
	
		PoolParams groupParams
		String groupName

		HealthMonitorParams hmParams
		HealthMonitorParams prevHmParams
		String hmId
		String prevHmId
		
		Iterator<String> groupsIter = incommingGroups.keySet().iterator()
		while (groupsIter.hasNext()) {
			groupName = groupsIter.next()
			groupParams = incommingGroups.get(groupName)
			
			hmParams = groupParams.healthmonitor
			if (hmParams.id.equals("none")) {
				hmParams.id = null
			}
			else {
				hmParams.id = getNoDashesUUID(hmParams.id)
			}
			prevHmParams = persistencyData.getHealthMonitorData(groupName)
			
			hmId = (hmParams == null) ? null :  hmParams.id;
			prevHmId = (prevHmParams == null) ? null :  prevHmParams.id;

			if (hmId != prevHmId) {
				if (prevHmId != null) {
					deviceConfigurator.configureHM(prevHmParams, groupName, DISSOCIATE_HM)
					persistencyData.removeHealthMonitorData(groupName)
				}
				if (hmId != null) {
					deviceConfigurator.configureHM(hmParams, groupName, ASSOCIATE_HM)
					persistencyData.setHealthMonitorData(groupName, hmParams)
				}
			}
			else if (hmId != null) {
				deviceConfigurator.configureHM(hmParams, groupName, UPDATE_HM)
			}
		}
	}

	public void setupStaticRoutes () {

		StaticRoute staticRoute
		Set<StaticRoute> newStaticRoutes = new HashSet<StaticRoute>()
		
		ListenerParams listener
		String virtName
		Map<String, MemberParams> memberParamsMap
		
		PoolParams groupParams
		String groupName
		
		Iterator<String> groupsIter = incommingGroups.keySet().iterator()
		while (groupsIter.hasNext()) {
			groupName = groupsIter.next()
			groupParams = incommingGroups.get(groupName)
			memberParamsMap = getGroupMemberParamsMap(groupParams)
			MemberParams memberParams

			Iterator<MemberParams> membersIter = memberParamsMap.values().iterator()
			while (membersIter.hasNext()) {
				memberParams = membersIter.next()
				if (persistencyData.addNewStaticRouteData(memberParams)) {
					newStaticRoutes.add(persistencyData.getStaticRouteData(memberParams.subnet))
				}
			}
		}
		
		StaticRoute[] staticRoutesArray = newStaticRoutes.toArray()
		if (staticRoutesArray.length > 0) {
			deviceConfigurator.configureStaticRoutes(staticRoutesArray)
		}
	}
	
	public void teardown () {
		Iterator<String> toDeleteVirtsIter = persistencyData.getVirtKeys().iterator()
		while (toDeleteVirtsIter.hasNext()) {
			tearDownVirt(toDeleteVirtsIter.next(), workflow['appwall_license']) 		
		}
		
		tearDownGroups();
	}
		
	private void tearDownVirt(String virtKey, boolean appWall) {
		LBVirt lbVirt = persistencyData.getVirtData(virtKey)
		
		deviceConfigurator.teardownVirt(
			virtKey, String.valueOf(lbVirt.port),
			getSrvrcertGroupId(virtKey), getIntermCaGroupId(virtKey),
			appWall)
		
		String curDefaultCertId = persistencyData.getVirtDefaultCertId(virtKey)
		String[] curSNICertIds = persistencyData.getVirtSNICertIds(virtKey)
		String[] curIntermCaIds = persistencyData.getVirtIntermCaCertIds(virtKey)
		
		if (curDefaultCertId != null) {
			deviceConfigurator.removeSrvrCertWithRefCount(curDefaultCertId)
		}
		for (int i = 0; i < curSNICertIds.length; i++) {
			deviceConfigurator.removeSrvrCertWithRefCount(curSNICertIds[i])
		}
		for (int i = 0; i < curIntermCaIds.length; i++) {
			deviceConfigurator.removeIntermCaWithRefCount(curIntermCaIds[i])
		}
		
		Map<String, L7PolicyParams> curL7Policies = persistencyData.getL7PoliciesData(virtKey)
		String policyId
		L7PolicyParams policy
		Iterator<String> policiesIter = curL7Policies.keySet().iterator()
		while (policiesIter.hasNext()) {
			policyId = policiesIter.next()
			policy = curL7Policies.get(policyId)
			deviceConfigurator.deleteL7Policy(virtKey, lbVirt.port, policyId, policy.position)
		}

		persistencyData.removeVirtData(virtKey)
		persistencyData.removeVirtDefaultCertId(virtKey)
		persistencyData.removeVirtSNICertIds(virtKey)
		persistencyData.removeVirtIntermCaCertIds(virtKey)
		persistencyData.removeVirtL7Policies(virtKey)
	}

	private void tearDownGroups() {
		String groupName;
		Set<String> groups = persistencyData.getGroups()
		Iterator<String> groupNameIter = groups.iterator()
		while (groupNameIter.hasNext()) {
			groupName = groupNameIter.next()
			
			Map<String, RealServer> realServersMap = persistencyData.getRealServers(groupName)
			List<String> deletedRealServerNames = new ArrayList<String>()
			deletedRealServerNames.addAll(realServersMap.keySet())

			HealthMonitorParams hmParams = persistencyData.getHealthMonitorData(groupName)
			if (hmParams != null && hmParams.id != null) {
				deviceConfigurator.configureHM(hmParams, groupName, DISSOCIATE_HM)
			}

			deviceConfigurator.configureGroup(groupName,
				"DEFAULT", "DEFAULT",
				true, true,
				new RealServerParams[0], new RealServerParams[0],
				deletedRealServerNames.toArray(new String[deletedRealServerNames.size()]))				
		}
	}

}