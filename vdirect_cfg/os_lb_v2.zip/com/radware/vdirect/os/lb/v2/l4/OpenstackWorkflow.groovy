package com.radware.vdirect.os.lb.v2.l4

import java.util.List;
import java.util.Map;

import javax.ws.rs.QueryParam;

import org.apache.commons.net.util.SubnetUtils;
import org.springframework.beans.factory.annotation.Autowired;

import com.google.common.net.InetAddresses;
import com.radware.alteon.api.events.UserEvent;
import com.radware.alteon.api.impl.EasyBean
import com.radware.alteon.api.AdcCLIConnectionBean;
import com.radware.alteon.api.AdcRuntimeException
import com.radware.alteon.api.AdcCLIConnection;
import com.radware.alteon.api.AdcTemplateResult;
import com.radware.alteon.api.AdcTimeoutException;
import com.radware.alteon.beans.adc.EnumActionType;
import com.radware.alteon.beans.adc.SlbNewCfgGroupEntry;
import com.radware.alteon.beans.adc.SlbNewCfgRealServerEntry;
import com.radware.alteon.beans.adc.VrrpInfo;
import com.radware.alteon.sdk.AdcInstanceType;
import com.radware.alteon.sdk.AdcManagementConfiguration;
import com.radware.alteon.sdk.AdcResourceId;
import com.radware.alteon.sdk.AdcCapacity;
import com.radware.alteon.sdk.AdcManagementConfiguration;
import com.radware.alteon.sdk.AdcPortgroupNetworkConfiguration;
import com.radware.alteon.sdk.IAdcInstance;
import com.radware.alteon.sdk.IPV4InterfaceInfo;
import com.radware.alteon.sdk.Tenant;
import com.radware.alteon.workflow.AdcWorkflowException;
import com.radware.alteon.workflow.impl.java.Devices;
import com.radware.alteon.sdk.containers.SoftAdcInfo;
import com.radware.alteon.sdk.impl.resources.wrapped.WrappedAdcService;
import com.radware.alteon.sdk.impl.resources.wrapped.WrappedNetwork;
import com.radware.alteon.sdk.impl.resources.wrapped.WrappedVrrpPool;
import com.radware.alteon.sdk.resources.IPAddressPool;
import com.radware.alteon.sdk.resources.IslId;
import com.radware.alteon.sdk.rpm.AdcAcceptableType;
import com.radware.alteon.sdk.rpm.AdcInstanceRequest;
import com.radware.alteon.sdk.rpm.AdcService;
import com.radware.alteon.sdk.rpm.AdcServiceAction;
import com.radware.alteon.sdk.rpm.AdcServiceRequest;
import com.radware.alteon.workflow.impl.DeviceConnection;
import com.radware.alteon.workflow.impl.WorkflowAdaptor;
import com.radware.alteon.workflow.impl.java.Action;
import com.radware.alteon.workflow.impl.java.ChildWorkflow;
import com.radware.alteon.workflow.impl.java.ConfigurationTemplate;
import com.radware.alteon.workflow.impl.java.Param;
import com.radware.alteon.workflow.impl.java.State;
import com.radware.alteon.workflow.impl.java.Device;
import com.radware.alteon.workflow.impl.java.Workflow;
import com.radware.logging.VDirectLogger;
import com.radware.vdirect.client.api.IAdcSessionBoundAccessManager;
import com.radware.vdirect.client.api.IAdcSessionBoundConfigurationTemplateManager;
import com.radware.vdirect.client.api.IAdcSessionBoundObjectFactory;
import com.radware.vdirect.client.sdk.IAdcSessionBoundContainerManager;
import com.radware.vdirect.client.sdk.IAdcSessionBoundResourceManager;
import com.radware.vdirect.client.sdk.IAdcSessionBoundResourcePoolManager;
import com.radware.vdirect.client.sdk.impl.InternalResourceManager;
import com.radware.alteon.api.impl.events.IEventManager;
import com.radware.alteon.beans.adc.SlbNewCfgEnhVirtualServerEntry;
import com.radware.vdirect.openstackv2.structures.*;
import com.radware.vdirect.os.lb.v2.l4.L4SetupUtility;
import com.radware.vdirect.os.lb.v2.l4.PortsData;
import com.radware.vdirect.os.lb.v2.l4.WaitForService;
import com.radware.vdirect.os.lb.v2.structures.persistent.HAInterface;
import com.radware.vdirect.os.lb.v2.structures.persistent.GroupRealServers;
import com.radware.vdirect.os.lb.v2.structures.persistent.Stats;
import com.radware.vdirect.os.lb.v2.structures.l4.ListenerParams;
import com.radware.vdirect.os.lb.v2.structures.persistent.StaticRoute;
import com.radware.vdirect.os.lb.v2.structures.persistent.LBVirt;
import com.radware.vdirect.os.lb.v2.structures.service.ServiceCapacityParams;
import com.radware.vdirect.os.lb.v2.structures.service.ServiceParams;
import com.radware.vdirect.os.lb.v2.structures.service.ServiceSpecParams;


/* The required @Workflow annotation marks this class as a workflow.
 * Note that workflow class definition MUST be the first class defined in the source file*/ 
@Workflow(
createAction='init',  /* Name of the optional create action */
deleteAction='teardown', /* Name of the optional delete action */
states = [ /* Required states used by the workflow */
	@State('initialized'),
	@State('applied'),
	@State('removed')],
properties = [
	/* These are the persistent properties of the workflow */

	// Debug Parameters
	@Param(name="provision_service", type="bool", prompt="Provision service?", defaultValue="True"),
	@Param(name="configure_l3", type="bool", prompt="Confire L3?", defaultValue="True"),
	@Param(name="configure_l4", type="bool", prompt="Confire L4?", defaultValue="True"),

	// Service Parameters
	@Param(name='service_params', type="ServiceParams", prompt='Radware vDirect ADC Service Parameters'),
	@Param(name='service', type="adcService", prompt='Radware vDirect ADC Service'),
	@Param(name='service_name', type="string", prompt='Radware vDirect ADC Service name'),
	@Param(name='service_id', type="object", prompt='Radware vDirect ADC Service id'),
	@Param(name="ha_enabled", type="bool", prompt="HA Enabled?", defaultValue="false"),

	// Workflow Parameters
	@Param(name="interface_ids", type="string[]", defaultValue='[]'),
	@Param(name="interface_vr_ids", type="string[]", defaultValue='[]'),
	@Param(name="gateway_id", type="int"),
	
	@Param(name="twoleg_enabled", type="bool", prompt="Two Leg Topology Enabled?", defaultValue="false"),
	@Param(name="ha_network_name", type="string", prompt="HA Network Name", defaultValue="HA-Network"),
	@Param(name="ha_ip_pool_name", type="string", prompt="HA IP pool name", defaultValue="HA-default"),
	@Param(name="allocate_ha_vrrp", type="bool", prompt="Allocate HA VRRP", defaultValue="True"),
	@Param(name="allocate_ha_ips", type="bool", prompt="Allocate HA IPs", defaultValue="True"),
	@Param(name="data_port", type="int", prompt="Data Port", defaultValue="1", max=2, min=1),
	@Param(name="data_ip_address", type="ip", prompt="Data IP Address", defaultValue="192.168.200.99"),
	@Param(name="data_ip_mask", type="ip", prompt="Data IP Mask", defaultValue="255.255.255.0"),
	@Param(name="gateway", type="ip", prompt="Default Gateway IP Address", defaultValue="192.168.200.1"),
	@Param(name="ha_port", type="int", prompt="HA Port", defaultValue="2", max=2, min=1),
	
	// Data Parameters
	@Param(name="vip_address", type="ip", prompt="VIP address", defaultValue="1.1.1.1"),
	@Param(name="pip_address", type="ip", prompt="PIP address", defaultValue="0.0.0.0"),
	@Param(name="admin_state_up", type="bool", prompt="Is loadbalancer enabled?", defaultValue="true"),
	@Param(name="listeners", type="ListenerParams[]"),
	
	@Param(name="lb_virts", type="object", defaultValue="{}"),
	@Param(name="lb_virts_default_cert", type="object", defaultValue="{}"),
	@Param(name="lb_virts_sni_certs", type="object", defaultValue="{}"),
	@Param(name="lb_virts_intermca_certs", type="object", defaultValue="{}"),
	@Param(name="group_real_servers", type="object", defaultValue="{}"),
	@Param(name="group_hms", type="object", defaultValue="{}"),
	@Param(name="static_routes", type="object", defaultValue="{}"),
	@Param(name="stats", type="object", defaultValue="{}")
	],
childWorkflows = ["manage_l3"])

class OpenstackWorkflow {

	/* Injected variables */
	@Autowired WorkflowAdaptor workflow
	@Autowired Devices devices
	@Autowired VDirectLogger log
	@Autowired IAdcSessionBoundObjectFactory factory
	@Autowired IEventManager events
	@Autowired IAdcSessionBoundResourcePoolManager services;
	@Autowired IAdcSessionBoundContainerManager containerManager;
	@Autowired IAdcSessionBoundResourceManager resourceManager;

	/* The @Action annotation marks the method as an action */
	@Action(
	fromState="none", /* Optional allowed fromState */ 
	toState="initialized", /* Optional final state for the action */
	visible=false /* Visible set to false hides the create action from end users */)
	void init (
			@Param(ref="provision_service") boolean provision_service,
			@Param(ref="configure_l3") boolean configure_l3,
			@Param(ref="configure_l4") boolean configure_l4,
			@Param(ref="service_params") ServiceParams service_params,
			@Param(ref="twoleg_enabled") boolean twoleg_enabled,
			@Param(ref="ha_network_name") String ha_network_name,
			@Param(ref="ha_ip_pool_name") String ha_ip_pool_name,
			@Param(ref="allocate_ha_vrrp") boolean allocate_ha_vrrp,
			@Param(ref="allocate_ha_ips") boolean allocate_ha_ips,
			@Param(ref="data_port") int data_port,
			@Param(ref="data_ip_address") String data_ip_address,
			@Param(ref="data_ip_mask") String data_ip_mask,
			@Param(ref="gateway") String gateway,
			@Param(ref="ha_port") int ha_port) {

		if (workflow.state != 'created') {
			return
		}

		workflow['twoleg_enabled'] = twoleg_enabled
		workflow['provision_service'] = provision_service
		workflow['configure_l3'] = configure_l3
		workflow['configure_l4'] = configure_l4
		
		if (!workflow['provision_service']) {
			return;
		}
		
		workflow['service_name'] = service_params.name;
		AdcResourceId serviceId = containerManager.getObjectId(service_params.name);
		if (serviceId == null) {
			serviceId = createService(service_params)
		}
		workflow['service_id'] = serviceId
		WrappedAdcService service = workflow.getAdcService(serviceId)
		WaitForService.wait(service, log, factory)
		
		workflow['service'] = service;
		log.info "Service is provisioned."
		
		devices.autoRevertOnError = true
				
		DeviceConfigurator deviceConfigurator = new DeviceConfigurator(workflow['service_name'], workflow, log)
		
		if (service.getService().getRequest().isHa() && 
			(deviceConfigurator.getPrimaryConnection() == null || deviceConfigurator.getSecondaryConnection() == null))
		{
			log.error "Not both HA devices are available. Halting init process.";
			return;
		}
		else if (deviceConfigurator.getPrimaryConnection() == null) {
			log.error "Device is not available. Halting init process.";
			return;
		}
		
		if (deviceConfigurator.getPrimaryConnection() != null) {
			devices['adc1'] = deviceConfigurator.getPrimaryConnection();
		}
		if (deviceConfigurator.getSecondaryConnection() != null) {
			devices['adc2'] = deviceConfigurator.getSecondaryConnection();
		}
		
		if (!workflow['configure_l3']) {
			return;
		}

		HAInterface[] l3_interfaces = PortsData.getInterfaces(service, workflow).toArray()
		ChildWorkflow workflow_l3 = workflow.getChildWorkflow("manage_l3")
		workflow_l3.parameters = ['service': service]
		workflow_l3.create("manage_l3")

		Integer service_ref_count = deviceConfigurator.registerWfOnService(workflow['service_name'])
		workflow_l3.parameters = ['service': service, 'l3_interfaces': l3_interfaces, 'dgw': workflow['gateway'], 'ip_version': 'v4']
		if (service_ref_count == 1) {	
			workflow_l3.update("setup_l3")
		}
		else {
			workflow_l3.update("setup_l3_get")
		}
		devices.commit(true, true, false)
		init_stats()
	}

	/* The fromState is actually an array of allowed states */
	@Action(fromState=["initialized","applied"], toState="applied")
	void apply (
			@Param(ref="vip_address") String vip_address,
			@Param(ref="pip_address") String pip_address,
			@Param(ref="admin_state_up") boolean admin_state_up,
			@Param(ref="listeners") ListenerParams[] listeners) {
			
		workflow['vip_address'] = vip_address
		workflow['pip_address'] = pip_address
		workflow['admin_state_up'] = admin_state_up
		
		devices.autoRevertOnError = true
		

		if (!workflow['provision_service']) {
			return
		}

		WrappedAdcService service = workflow.get("service", WrappedAdcService)
		DeviceConfigurator deviceConfigurator = new DeviceConfigurator(workflow['service_name'], workflow, log);
		
		if (service.getService().getRequest().isHa() && 
			(deviceConfigurator.getPrimaryConnection() == null || deviceConfigurator.getSecondaryConnection() == null))
		{
			log.error "Not both HA devices are available. Halting apply process.";
			return;
		}
		else if (deviceConfigurator.getPrimaryConnection() == null) {
			log.error "Device is not available. Halting apply process.";
			return;
		}

		if (deviceConfigurator.getPrimaryConnection() != null) {
			devices['adc1'] = deviceConfigurator.getPrimaryConnection();
		}
		if (deviceConfigurator.getSecondaryConnection() != null) {
			devices['adc2'] = deviceConfigurator.getSecondaryConnection();
		}

		L4SetupUtility l4setup = new L4SetupUtility(deviceConfigurator, workflow['service_name'], workflow, log, listeners)
		
		if (!workflow['configure_l4']) {
			return
		}
		
		log.info "Starting L4 setup"
		l4setup.setupVirts()
		log.info "Virts setup applied"
		
		log.info "Starting TLS setup"
		l4setup.setupVirtsTLS()
		devices.commit(true, false, false)
		log.info "Virts TLS setup applied"

		l4setup.setupRealServers()
		devices.commit(true, false, false)
		log.info "Real servers setup applied"
		
		l4setup.setupHealthMonitors()
		devices.commit(true, false, false)
		log.info "Health monitors setup applied"
		
		l4setup.setupStaticRoutes()
		log.info "Static routes setup applied"
		
		devices.commit(true, true, false)
		log.info "L4 setup saved"
		
		l4setup.persistWFPersistentData()
	}

	@Action(toState='removed')
	void teardown () {

		if (workflow.state == 'removed') {
			return
		}

		if (!workflow['provision_service']) {
			return
		}

		WrappedAdcService service = workflow.get("service", WrappedAdcService)
		devices.autoRevertOnError = true

		DeviceConfigurator deviceConfigurator = new DeviceConfigurator(workflow['service_name'], workflow, log);
		
		if (service.getService().getRequest().isHa() &&
			(deviceConfigurator.getPrimaryConnection() == null || deviceConfigurator.getSecondaryConnection() == null))
		{
			log.error "Not both HA devices are available. Halting teardown process.";
			return;
		}
		else if (deviceConfigurator.getPrimaryConnection() == null) {
			log.error "Device is not available. Halting teardown process.";
			return;
		}

		if (deviceConfigurator.getPrimaryConnection() != null) {
			devices['adc1'] = deviceConfigurator.getPrimaryConnection();
		}
		if (deviceConfigurator.getSecondaryConnection() != null) {
			devices['adc2'] = deviceConfigurator.getSecondaryConnection();
		}

		Integer service_ref_count = deviceConfigurator.unregisterWfOnService(workflow['service_name'])
		if (workflow['configure_l4']) {
			L4SetupUtility l4setup = new L4SetupUtility(deviceConfigurator, workflow['service_name'], workflow, log)
			l4setup.teardown()
			devices.commit(true, true, false)
			l4setup.clearWFPersistentData()
		}
		
		if (workflow['configure_l3']) {
			if (service_ref_count != null && service_ref_count == 0) {
				ChildWorkflow workflow_l3 = workflow.getChildWorkflow("manage_l3")
				workflow_l3.delete()
				devices.commit(true, true, false)
				//services.deleteService(workflow['service_id'].uniqueId)
			}
		}
	}

	@Action(fromState=["applied"], toState="applied")
	void stats () {

		DeviceConfigurator deviceConfigurator = new DeviceConfigurator(workflow['service_name'], workflow, log);
		L4SetupUtility l4setup = new L4SetupUtility(deviceConfigurator, workflow['service_name'], workflow, log)
		
		Stats stats = deviceConfigurator.getLbStatistics(l4setup.persistencyData.getVirtKeys())
		
		if (stats == null) {
			return;
		}
		
		workflow['stats'].active_connections = stats.active_connections
		workflow['stats'].total_connections = stats.total_connections
		workflow['stats'].bytes_in = stats.bytes_in
		workflow['stats'].bytes_out = stats.bytes_out
	}

	private init_stats() {
		Stats stats = new Stats()
		stats.active_connections = 0
		stats.total_connections = 0
		stats.bytes_in = 0
		stats.bytes_out = 0
		workflow['stats'] = stats
	}
	
	private AdcResourceId createService (ServiceParams serviceParams) {
		AdcServiceRequest spec = new AdcServiceRequest()
		spec.setAcceptableAdc(Enum.valueOf(AdcAcceptableType, serviceParams.primary.acceptableAdc))
		spec.setAdcType(Enum.valueOf(AdcInstanceType, serviceParams.primary.adcType))
	
		Set<AdcResourceId> resourceIds = new HashSet<AdcResourceId>()
		for(int counter = 0; counter < serviceParams.resourcePoolIds.length; counter++ ) {
			resourceIds.add(AdcResourceId.decode(serviceParams.resourcePoolIds[counter].id + "//"))
		}
		spec.setResourcePoolIds(resourceIds)
		spec.setIslVlan(serviceParams.islVlan)
		AdcCapacity adcCapacity = new AdcCapacity()
		adcCapacity.setThroughput(serviceParams.primary.capacity.throughput)
		adcCapacity.setSslThroughput(serviceParams.primary.capacity.sslThroughput)
		adcCapacity.setCompressionThroughput(serviceParams.primary.capacity.compressionThroughput)
		adcCapacity.setCache(serviceParams.primary.capacity.cache)
		spec.setCapacity(adcCapacity)
	
		AdcPortgroupNetworkConfiguration adcPortgroupNetworkConfiguration = new AdcPortgroupNetworkConfiguration()
		List<String> portGroups = new ArrayList<String>()
		for(int counter = 0; counter < serviceParams.primary.network.portgroups.length; counter++ ) {
			portGroups.add(serviceParams.primary.network.portgroups[counter])
		}
		
		adcPortgroupNetworkConfiguration.setPortgroups(portGroups)
		spec.setNetwork(adcPortgroupNetworkConfiguration);
		
		if (serviceParams.haPair) {
			spec.setSecondary(new AdcInstanceRequest())
		}
		
		Tenant tenant = resourceManager.getTenant(serviceParams.tenantId);
		if(tenant == null) {
			tenant = new Tenant(serviceParams.tenantId)
			tenant.setDescription("Tenant for " + serviceParams.name)
			resourceManager.createTenant(tenant);
		}
		
		return services.createService(spec, serviceParams.name, false, serviceParams.tenantId)
	}
}