package com.radware.vdirect.os.lb.v2.structures.l4

import com.radware.alteon.workflow.impl.java.Param;

public class MemberParams {
	@Param(type="string", prompt="Member OS UUID", defaultValue="0")
	public String id;
	@Param(type="ip", prompt="Member IP address", defaultValue="1.1.1.2")
	public String address;
	@Param(type="int", prompt="Member protocol port", defaultValue="81")
	public int protocol_port;
	@Param(type="int", prompt="Member weight", defaultValue="30")
	public int weight;
	@Param(type="bool", prompt="Is member enabled?", defaultValue="true")
	public boolean admin_state_up;
	@Param(type="ip", prompt="Member subnet", defaultValue="255.255.255.255")
	public String subnet;
	@Param(type="ip", prompt="Member mask", defaultValue="255.255.255.255")
	public String mask;
	@Param(type="ip", prompt="Member GW", defaultValue="255.255.255.255")
	public String gw;
}
