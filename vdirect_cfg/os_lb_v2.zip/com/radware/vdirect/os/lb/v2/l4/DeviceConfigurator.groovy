package com.radware.vdirect.os.lb.v2.l4

import java.util.List;
import java.util.Map;

import com.radware.alteon.api.AdcTemplateResult;
import com.radware.alteon.workflow.impl.DeviceConnection;
import com.radware.alteon.workflow.impl.WorkflowAdaptor;
import com.radware.alteon.workflow.impl.java.ConfigurationTemplate;
import com.radware.logging.VDirectLogger;
import com.radware.vdirect.os.lb.v2.structures.l4.HealthMonitorParams;
import com.radware.vdirect.os.lb.v2.structures.l4.RealServerParams;
import com.radware.vdirect.os.lb.v2.structures.l4.SNITLSCertificateParams;
import com.radware.vdirect.os.lb.v2.structures.l4.TLSCertificateParams;
import com.radware.vdirect.os.lb.v2.structures.persistent.CertIntermediate;
import com.radware.vdirect.os.lb.v2.structures.persistent.StaticRoute;

public class DeviceConfigurator {
	
	public static final String DISASSOCIATE_HM = "disassociate"
	public static final String ASSOCIATE_HM = "associate"
	public static final String UPDATE_HM = "update"
	public static final String SERVICE_WFS = "SERVICE_WFS"
	public static final String SRVRCERT = "SRVRCERT"
	public static final String INTERMCA = "INTERMCA"
	
	WorkflowAdaptor workflow
	VDirectLogger log
	DeviceConnection primary_connection
	DeviceConnection secondary_connection
	String serviceName;
	boolean haPair = true
	
	public DeviceConfigurator (String service_name, 
		DeviceConnection primary_connection,
		WorkflowAdaptor workflow, VDirectLogger logger) {
		
		this.workflow = workflow
		this.log = logger
		this.primary_connection = primary_connection
		this.secondary_connection = null
		this.serviceName = service_name
		this.haPair = false
	}
		
	public boolean isHAPair () {
		return this.haPair
	}

	public DeviceConfigurator (String service_name, 
		DeviceConnection primary_connection, DeviceConnection secondary_connection,
		WorkflowAdaptor workflow, VDirectLogger logger) {
		
		this.workflow = workflow
		this.log = logger
		this.primary_connection = primary_connection
		this.secondary_connection = secondary_connection
		this.serviceName = service_name
	}

	/*
	public Integer getFreeIndex (String beanName, Integer startingIndex) { 
		return connection.getFreeIndex(beanName, startingIndex)
	}
	*/
	
	private void runTemplateOnDevice(ConfigurationTemplate template, Map<String, Object> params,
			DeviceConnection connection, boolean retry) {
		template.setShareConnections(false)
		params.put('adc', connection)
		template.parameters = params
		AdcTemplateResult res = template.run()
		String output = res.getCliOutput()
		if (retry){
			params.put('retry', true)
			int retries = 1
			while (output.contains("Error:") && retries <= 25) {
				log.info('Template failed, retrying ...(' + retries + ' of 25)')
				template.parameters = params
				res = template.run()
				output = res.getCliOutput()
				retries++
			}
		}		
	}

	private void runTemplate(String templateName, Map<String, Object> params) {
		runTemplate(templateName, params, false)
	}
		
	private void runTemplate(String templateName, Map<String, Object> params, boolean retry) {
		ConfigurationTemplate template = workflow.getTemplate(templateName)
		//template.setShareConnections(false)
		//params.put('adc', this.primary_connection)
		//template.parameters = params
		//AdcTemplateResult res = template.run()
		//String output = res.getCliOutput()
		//log.info('Template ' + templateName + ' CLI output:' + output)
		runTemplateOnDevice(template, params, this.primary_connection, retry)
		if (isHAPair()) {
			runTemplateOnDevice(template, params, this.secondary_connection, retry)
		}
		//if (retry){
		//	params.put('retry', true)
		//	int retries = 1
		//	while (output.contains("Error:") && retries <= 25) {
		//		log.info('Template ' + templateName + ' failed, retrying ...(' + retries + ' of 25)')
		//		template.parameters = params
		//		res = template.run()
		//		output = res.getCliOutput()
		//		retries++
		//	}
		//}
	}
	
	public void configureVirt (String virtName, String groupName,
		String port, String protocol,
		String portAlgorythm, boolean pool_admin_state_up,
		String session_persistence_type,
		String session_persistence_cookie_name) {
							  
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			//'adc': this.connection,
			'virtName': virtName,
			'groupName': groupName,
			'virtServerEnabled': workflow['admin_state_up'],
			'vip': workflow['vip_address'],
			'pip_address': workflow['pip_address'],
			'virtSvcPort': port,
			'virtSvcType': protocol,
			'svcPortAlgorithm': portAlgorythm,
			'groupEnabled': pool_admin_state_up,
			'virtSvcPersistMethod': session_persistence_type,
			'virtSvcCookieName': session_persistence_cookie_name])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/openstack_manage_l4.vm", params)
	}

	public Integer registerWfOnService (String serviceName) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			//'adc': this.connection,
			'type': SERVICE_WFS,
			'key': serviceName,
			'action': 'increment'])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/openstack_refcount.vm", params)
		return workflow['ref_value']		
	}

	public Integer unregisterWfOnService (String serviceName) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			//'adc': this.connection,
			'type': SERVICE_WFS,
			'key': serviceName,
			'action': 'decrement'])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/openstack_refcount.vm", params)
		return workflow['ref_value']
	}

	public void addSrvrCertWithRefCount (TLSCertificateParams certParams) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			//'adc': this.connection,
			'type': SRVRCERT,
			'key': certParams.id,
			'action': 'increment'])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/openstack_refcount.vm", params)

		// If reference count is "1", meaning the certificate was not used until now, create it
		if (workflow['ref_value'] == 1) {
			params = new HashMap<String, Object>()
			params.putAll([
				//'adc': this.connection,
				'certsParams': [certParams]])
			
			runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/create_srvrcert_key.vm", params, true)
			runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/create_srvrcert.vm", params, true)
		}
	}
	
	public void removeSrvrCertWithRefCount (String certId) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			//'adc': this.connection,
			'type': SRVRCERT,
			'key': certId,
			'action': 'decrement'])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/openstack_refcount.vm", params)

		// If reference count is "0", meaning the certificate is not used for now, remove it
		if (workflow['ref_value'] == 0) {
			params = new HashMap<String, Object>()
			params.putAll([
				//'adc': this.connection,
				'certIds': [certId]])
			
			runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/remove_srvrcert.vm", params)
		}
	}

	public void addIntermCaWithRefCount (CertIntermediate intermca) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			//'adc': this.connection,
			'type': INTERMCA,
			'key': intermca.id,
			'action': 'increment'])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/openstack_refcount.vm", params)
		
		// If reference count is "1", meaning the certificate was not used until now, create it
		if (workflow['ref_value'] == 1) {
		params = new HashMap<String, Object>()
			params.putAll([
				//'adc': this.connection,
				'intermCas': [intermca]])
			
			runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/create_intermca.vm", params, true)
		}
	}
	
	public void removeIntermCaWithRefCount (String intermCaId) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			//'adc': this.connection,
			'type': INTERMCA,
			'key': intermCaId,
			'action': 'decrement'])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/openstack_refcount.vm", params)
	
		// If reference count is "0", meaning the certificate is not used for now, remove it
		if (workflow['ref_value'] == 0) {
			params = new HashMap<String, Object>()
			params.putAll([
				//'adc': this.connection,
				'intermCaIds': [intermCaId]])
			
			runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/remove_intermca.vm", params)
		}
	}

	public void configureSrvrCertGroupDefault (String virtName, String port, String groupName, String certId, String oldCertId) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			//'adc': this.connection,
			'virtName': virtName,
			'groupName': groupName,
			'port': port,
			'oldDefaultCertId': oldCertId,
			'defaultCertId': certId])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/manage_srvrcert_group_default.vm", params)
	}

	public void configureSrvrCertGroupSNI (String virtName,	String port, String groupName, 
		String[] curSniCertIds, String[] newSniCertIds) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			//'adc': this.connection,
			'virtName': virtName,
			'groupName': groupName,
			'port': port,
			'oldSniCertIds': curSniCertIds,
			'newSniCertIds': newSniCertIds])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/manage_srvrcert_group_sni.vm", params)
	}

	public void configureIntermCaGroup (String virtName, String port, String groupName,
		String[] curIntermCaIds, String[] newIntermCaIds) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			//'adc': this.connection,
			'virtName': virtName,
			'groupName': groupName,
			'port': port,
			'oldIntermCaIds': curIntermCaIds,
			'newIntermCaIds': newIntermCaIds])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/manage_intermca_group.vm", params)
	}

	public void teardownVirt (String virtName, String port, String[] realServerNamesArray,
		String groupName, String srvrcertGroupName, String intermcaGroupName) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			//'adc': this.connection,
			'groupName': groupName,
			'intermcaGroupName': intermcaGroupName,
			'srvrcertGroupName': srvrcertGroupName,
			'virtName': virtName,
			'port': port, 
			'curRealServerNames': realServerNamesArray])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/openstack_teardown_l4.vm", params)
	}
	
	public void configureGroup (String groupName, boolean groupEnabled,
				RealServerParams[] newRealServers,
				RealServerParams[] updatedRealServers,
				String[] deletedRealServersNames) {
	
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			//'adc': this.connection,
			'groupName': groupName,
			'groupEnabled': groupEnabled,
			'newRealServers': newRealServers,
			'updatedRealServers': updatedRealServers,
			'deletedRealServersNames': deletedRealServersNames])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/openstack_manage_rips.vm", params)
	}

				
	public void configureHM (HealthMonitorParams hmParams, String groupName, String action) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			//'adc': this.connection,
			'hm': hmParams,
			'groupName': groupName,
			'action': action])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/openstack_manage_hm_no_ref_count.vm", params)
	}
	
	public void configureStaticRoutes (StaticRoute[] staticRoutesArray) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			//'adc': this.connection,
			'new_static_routes': staticRoutesArray])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/openstack_manage_static_routes.vm", params)
	}
}