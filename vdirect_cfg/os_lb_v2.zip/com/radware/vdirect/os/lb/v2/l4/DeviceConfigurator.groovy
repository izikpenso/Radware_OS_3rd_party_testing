package com.radware.vdirect.os.lb.v2.l4

import java.util.List;
import java.util.Map;
import java.net.Inet4Address;
import java.nio.charset.StandardCharsets;

import org.springframework.beans.factory.annotation.Autowired;

import javassist.expr.Instanceof;

import com.radware.alteon.api.AdcTemplateResult;
import com.radware.alteon.beans.adc.IfXEntry;
import com.radware.alteon.beans.adc.IpNewCfgStaticRouteEntry;
import com.radware.alteon.beans.adc.Ipv6NewCfgStaticRouteEntry;
import com.radware.alteon.beans.adc.SlbStatEnhVServerEntry;
import com.radware.alteon.beans.adc.VrrpInfo;
import com.radware.alteon.sdk.IAdcObject;
import com.radware.alteon.sdk.impl.resources.wrapped.WrappedAdcService;
import com.radware.alteon.workflow.impl.DeviceConnection;
import com.radware.alteon.workflow.impl.WorkflowAdaptor;
import com.radware.alteon.workflow.impl.java.ConfigurationTemplate;
import com.radware.alteon.workflow.impl.java.Devices;
import com.radware.logging.VDirectLogger;
import com.radware.vdirect.os.lb.v2.structures.l4.HealthMonitorParams;
import com.radware.vdirect.os.lb.v2.structures.l4.RealServerParams;
import com.radware.vdirect.os.lb.v2.structures.l4.SNITLSCertificateParams;
import com.radware.vdirect.os.lb.v2.structures.l4.TLSCertificateParams;
import com.radware.vdirect.os.lb.v2.structures.persistent.CertIntermediate;
import com.radware.vdirect.os.lb.v2.structures.persistent.StaticRoute;
import com.radware.vdirect.os.lb.v2.structures.persistent.Stats;

public class DeviceConfigurator {
	public static final String DISASSOCIATE_HM = "disassociate"
	public static final String ASSOCIATE_HM = "associate"
	public static final String UPDATE_HM = "update"
	public static final String SERVICE_WFS = "SERVICE_WFS"
	public static final String SRVRCERT = "SRVRCERT"
	public static final String INTERMCA = "INTERMCA"
	
	WorkflowAdaptor workflow
	VDirectLogger log
	DeviceConnection primary_connection
	DeviceConnection secondary_connection
	String serviceName;
	
	public DeviceConfigurator (String service_name, 
		WorkflowAdaptor workflow, VDirectLogger logger) {
		
		this.workflow = workflow
		this.log = logger
		this.serviceName = service_name
		
		setDeviceConnections();
	}
		
	private boolean isDeviceReachable (String address) {
		WrappedAdcService service = workflow.get("service", WrappedAdcService);
		InetAddress inet_addr = InetAddress.getByName(address);
		
		boolean reachable = true;
		
		try {
			reachable = inet_addr.isReachable(1000);
		}
		catch (IOException e) {
			reachable = false
		}

		return reachable;
	}

	private void setDeviceConnections() {
		WrappedAdcService service = workflow.get("service", WrappedAdcService);
		
		DeviceConnection master_conn;
	
		boolean primary_reachable = isDeviceReachable(service.getPrimaryAdc().getConnectionDetails().getAddress());
		if (primary_reachable) {
			this.primary_connection = workflow.getDevices().connect(service.getPrimary())
			
		}
		else {
			log.warn("Primary device instance is not reachable");
		}

		boolean secondary_reachable = false;
		if (service.getService().getRequest().isHa()) {
			workflow['ha_enabled'] = true;
			secondary_reachable = isDeviceReachable(service.getSecondaryAdc().getConnectionDetails().getAddress());
			if (secondary_reachable) {
				this.secondary_connection = workflow.getDevices().connect(service.getSecondary());
			}
			else {
				log.warn("Secondary device instance is not reachable");
			}
		}
		else {
			workflow['ha_enabled'] = false;
		}
	
		if (!primary_reachable && !secondary_reachable) {
			log.error("No available device instance.");
			return
		}
	
	}
		
	public DeviceConnection getPrimaryConnection() {
		return this.primary_connection;
	}

	public DeviceConnection getSecondaryConnection() {
		return this.secondary_connection;
	}

	public DeviceConnection getMasterConnection() {
			
		log.info("Getting master device conection.");
		WrappedAdcService service = workflow.get("service", WrappedAdcService);
		
		DeviceConnection master_conn;
	
		boolean primary_reachable = isDeviceReachable(service.getPrimaryAdc().getConnectionDetails().getAddress());
		boolean secondary_reachable = false;
		if (service.getService().getRequest().isHa()) {
			secondary_reachable = isDeviceReachable(service.getSecondaryAdc().getConnectionDetails().getAddress());
		}
		else if (primary_reachable) {
			return this.primary_connection;
			log.info("Primary is master device.");
		}

		if (primary_reachable) {
			VrrpInfo primaryVrrpInfo = new VrrpInfo()
			VrrpInfo primaryVrrpInfo2 = this.primary_connection.read(primaryVrrpInfo);
			if (primaryVrrpInfo2.vrrpInfoHAState.equalsIgnoreCase("master")) {
				log.info("Primary is master device.");
				master_conn = this.primary_connection;
			}
			else if (secondary_reachable) {
				VrrpInfo secondaryVrrpInfo = new VrrpInfo()
				VrrpInfo secondaryVrrpInfo2 = this.secondary_connection.read(secondaryVrrpInfo);
				if (secondaryVrrpInfo2.vrrpInfoHAState.equalsIgnoreCase("master")) {
					log.info("Secondary is master device.");
					master_conn = this.secondary_connection;
				}
				else {
					log.warn("Primary and secondary instances in HA pair are not MASTER.");
				}
			}
			else {
				log.warn("Primary instance is the only reachable instance but is not a MASTER.");
			}
		}
		else if (secondary_reachable) {
			VrrpInfo myVrrpInfo = new VrrpInfo()
			VrrpInfo myVrrpInfo2 = this.secondary_connection.read(myVrrpInfo);
			if (myVrrpInfo2.vrrpInfoHAState.equalsIgnoreCase("master")) {
				master_conn = this.secondary_connection;
			}
			else {
				log.warn("secondary instance is the only reachable instance but is not a MASTER.");
			}
		}
		else {
			log.error("No device instance is reachable.");
		}
	
		return master_conn;
	}

	private void runTemplateOnDevice(ConfigurationTemplate template, Map<String, Object> params,
			DeviceConnection connection, boolean retry) {
		template.setShareConnections(false)
		params.put('adc', connection)
		template.parameters = params
		AdcTemplateResult res = template.run()
		String output = res.getCliOutput()
		if (retry){
			String deviceName = "UNKNOWN";
			Object deviceObject = connection.getConnection()
			if (deviceObject instanceof IAdcObject) {
				deviceName = ((IAdcObject)deviceObject).getMOI().getName()
			}
			IAdcObject
			int retries = 1
			while (output.contains("Error:") && retries <= 25) {
				log.info('Template failed on device ' + deviceName + ', retrying ...(' + retries + ' of 25)')
				template.parameters = params
				res = template.run()
				output = res.getCliOutput()
				retries++
			}
		}		
	}

	private void runTemplate(String templateName, Map<String, Object> params) {
		runTemplate(templateName, params, false)
	}
		
	private void runTemplate(String templateName, Map<String, Object> params, boolean retry) {
		ConfigurationTemplate template = workflow.getTemplate(templateName)
		if (this.primary_connection != null) {
			runTemplateOnDevice(template, params, this.primary_connection, retry)
		}
		if (this.secondary_connection != null) {
			runTemplateOnDevice(template, params, this.secondary_connection, retry)
		}
	}
	
	public Map<String, StaticRoute> getStaticRoutes () {
		
		Map<String, StaticRoute> retVal = new HashMap<String, StaticRoute>()

		DeviceConnection master_conn = getMasterConnection();
		if (master_conn == null) {
			master_conn = this.primary_connection;
		}
		
		if (master_conn == null) {
			return retVal;
		}
		
		IpNewCfgStaticRouteEntry ipv4staticRouteBean
		Ipv6NewCfgStaticRouteEntry ipv6staticRouteBean
		StaticRoute staticRoute;
		
		List<IpNewCfgStaticRouteEntry> ipv4staticRouteBeans = master_conn.readAllBeans('IpNewCfgStaticRouteEntry')
		Iterator<IpNewCfgStaticRouteEntry> ipv4staticRouteBeansIter = ipv4staticRouteBeans.iterator()
		while (ipv4staticRouteBeansIter.hasNext()) {
			ipv4staticRouteBean = ipv4staticRouteBeansIter.next()
			staticRoute = new StaticRoute()
			staticRoute.destinationIp = ipv4staticRouteBean.getDestIp()
			staticRoute.gatewayIp = ipv4staticRouteBean.getGateway()
			staticRoute.maskIp = ipv4staticRouteBean.getMask()
			retVal.put(staticRoute.destinationIp, staticRoute)
		}

		List<Ipv6NewCfgStaticRouteEntry> ipv6staticRouteBeans = master_conn.readAllBeans('Ipv6NewCfgStaticRouteEntry')
		Iterator<Ipv6NewCfgStaticRouteEntry> ipv6staticRouteBeansIter = ipv6staticRouteBeans.iterator()
		while (ipv6staticRouteBeansIter.hasNext()) {
			ipv6staticRouteBean = ipv6staticRouteBeansIter.next()
			staticRoute = new StaticRoute()
			staticRoute.destinationIp = ipv6staticRouteBean.getDestIp()
			staticRoute.gatewayIp = ipv6staticRouteBean.getGateway()
			staticRoute.maskIp = ipv6staticRouteBean.getMask()
			retVal.put(staticRoute.destinationIp, staticRoute)
		}

		return retVal
	}

	public void configureVirt (String virtName, String groupName,
		String port, String protocol,
		String portAlgorythm, boolean pool_admin_state_up,
		String session_persistence_type,
		String session_persistence_cookie_name) {
							  
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			'virtName': virtName,
			'groupName': groupName,
			'virtServerEnabled': workflow['admin_state_up'],
			'vip': workflow['vip_address'],
			'pip_address': workflow['pip_address'],
			'virtSvcPort': port,
			'virtSvcType': protocol,
			'svcPortAlgorithm': portAlgorythm,
			'groupEnabled': pool_admin_state_up,
			'virtSvcPersistMethod': session_persistence_type,
			'virtSvcCookieName': session_persistence_cookie_name])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/openstack_manage_l4.vm", params)
	}

	public Integer registerWfOnService (String serviceName) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			'type': SERVICE_WFS,
			'key': serviceName,
			'action': 'increment'])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/openstack_refcount.vm", params)
		return workflow['ref_value']		
	}

	public Integer unregisterWfOnService (String serviceName) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			'type': SERVICE_WFS,
			'key': serviceName,
			'action': 'decrement'])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/openstack_refcount.vm", params)
		return workflow['ref_value']
	}

	public void addSrvrCertWithRefCount (TLSCertificateParams certParams) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			'type': SRVRCERT,
			'key': certParams.id,
			'action': 'increment'])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/openstack_refcount.vm", params)

		// If reference count is "1", meaning the certificate was not used until now, create it
		if (workflow['ref_value'] == 1) {
			params = new HashMap<String, Object>()
			params.putAll([
				'certsParams': [certParams]])
			
			runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/create_srvrcert_key.vm", params, true)
			runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/create_srvrcert.vm", params, true)
		}
	}
	
	public void removeSrvrCertWithRefCount (String certId) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			'type': SRVRCERT,
			'key': certId,
			'action': 'decrement'])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/openstack_refcount.vm", params)

		// If reference count is "0", meaning the certificate is not used for now, remove it
		if (workflow['ref_value'] == 0) {
			params = new HashMap<String, Object>()
			params.putAll([
				'certIds': [certId]])
			
			runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/remove_srvrcert.vm", params)
		}
	}

	public void addIntermCaWithRefCount (CertIntermediate intermca) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			'type': INTERMCA,
			'key': intermca.id,
			'action': 'increment'])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/openstack_refcount.vm", params)
		
		// If reference count is "1", meaning the certificate was not used until now, create it
		if (workflow['ref_value'] == 1) {
		params = new HashMap<String, Object>()
			params.putAll([
				'intermCas': [intermca]])
			
			runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/create_intermca.vm", params, true)
		}
	}
	
	public void removeIntermCaWithRefCount (String intermCaId) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			'type': INTERMCA,
			'key': intermCaId,
			'action': 'decrement'])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/openstack_refcount.vm", params)
	
		// If reference count is "0", meaning the certificate is not used for now, remove it
		if (workflow['ref_value'] == 0) {
			params = new HashMap<String, Object>()
			params.putAll([
				'intermCaIds': [intermCaId]])
			
			runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/remove_intermca.vm", params)
		}
	}

	public void configureSrvrCertGroupDefault (String virtName, String port, String groupName, String certId, String oldCertId) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			'virtName': virtName,
			'groupName': groupName,
			'port': port,
			'oldDefaultCertId': oldCertId,
			'defaultCertId': certId])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/manage_srvrcert_group_default.vm", params)
	}

	public void configureSrvrCertGroupSNI (String virtName,	String port, String groupName, 
		String[] curSniCertIds, String[] newSniCertIds) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			'virtName': virtName,
			'groupName': groupName,
			'port': port,
			'oldSniCertIds': curSniCertIds,
			'newSniCertIds': newSniCertIds])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/manage_srvrcert_group_sni.vm", params)
	}

	public void configureIntermCaGroup (String virtName, String port, String groupName,
		String[] curIntermCaIds, String[] newIntermCaIds) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			'virtName': virtName,
			'groupName': groupName,
			'port': port,
			'oldIntermCaIds': curIntermCaIds,
			'newIntermCaIds': newIntermCaIds])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/ssl/manage_intermca_group.vm", params)
	}

	public void teardownVirt (String virtName, String port, String[] realServerNamesArray,
		String groupName, String srvrcertGroupName, String intermcaGroupName) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			'groupName': groupName,
			'intermcaGroupName': intermcaGroupName,
			'srvrcertGroupName': srvrcertGroupName,
			'virtName': virtName,
			'port': port, 
			'curRealServerNames': realServerNamesArray])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/openstack_teardown_l4.vm", params)
	}
	
	public void configureGroup (String groupName, boolean groupEnabled,
				RealServerParams[] newRealServers,
				RealServerParams[] updatedRealServers,
				String[] deletedRealServersNames) {
	
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			'groupName': groupName,
			'groupEnabled': groupEnabled,
			'newRealServers': newRealServers,
			'updatedRealServers': updatedRealServers,
			'deletedRealServersNames': deletedRealServersNames])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/openstack_manage_rips.vm", params)
	}

				
	public void configureHM (HealthMonitorParams hmParams, String groupName, String action) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			'hm': hmParams,
			'groupName': groupName,
			'action': action])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/openstack_manage_hm_no_ref_count.vm", params)
	}
	
	public void configureStaticRoutes (StaticRoute[] staticRoutesArray) {
		Map<String, Object> params = new HashMap<String, Object>()
		params.putAll([
			'new_static_routes': staticRoutesArray])
		
		runTemplate("com/radware/vdirect/os/lb/v2/l4/openstack_manage_static_routes.vm", params)
	}
	
	public Stats getLbStatistics (Set<String> virts) {
		
		DeviceConnection master_conn = getMasterConnection();
		if (master_conn == null) {
			log.error("No device instance is reachable. No statistics will be collected");
			return null;	
		}
		
		log.info("Stats will be collected from " + master_conn.connection.address + " device instance");
		
		IfXEntry ifx = master_conn.readBean('IfXEntry', 257);
		Long inOcets = ifx.getHCInOctets();
		Long outOcets = ifx.getHCOutOctets();
		Long totalOcets = inOcets + outOcets;
		double inOctetsPercent = inOcets / totalOcets;
		double outOctetsPercent = outOcets / totalOcets;
		
		Long vipCurrSessions = 0
		Long vipTotalSessions = 0
		Long vipInOctets = 0
		Long vipOutOctets = 0
		
		Iterator<String> virtsIter = virts.iterator()
		while (virtsIter.hasNext()) {
			String virtKey = virtsIter.next();
			SlbStatEnhVServerEntry virtStat = master_conn.readBean('SlbStatEnhVServerEntry', 'index', virtKey);
			vipCurrSessions += virtStat.getCurrSessions();
			vipTotalSessions += virtStat.getTotalSessions();
			vipInOctets += virtStat.getHCOctets() * inOctetsPercent;
			vipOutOctets += virtStat.getHCOctets() * outOctetsPercent;
		}
	
		Stats stats = new Stats();
		stats.active_connections = vipCurrSessions;
		stats.total_connections = vipTotalSessions;
		stats.bytes_in = vipInOctets;
		stats.bytes_out = vipOutOctets;
		
		return stats;
	}

}