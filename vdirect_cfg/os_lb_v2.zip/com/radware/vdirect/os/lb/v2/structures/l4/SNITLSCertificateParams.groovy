package com.radware.vdirect.os.lb.v2.structures.l4

import com.radware.alteon.workflow.impl.java.Param;

public class SNITLSCertificateParams {
	@Param(type="string", prompt="Certificate id", defaultValue="null")
	public String id;
	@Param(type="string", prompt="Certificate", defaultValue="", format="pem")
	public String certificate;
	@Param(type="string", prompt="Intermediates", defaultValue="")
	public String intermediates;
	@Param(type="string", prompt="Private key", defaultValue="", format="pem")
	public String private_key;
	@Param(type="string", prompt="Private key passphrase", defaultValue="")
	public String passphrase;
	@Param(type="string", prompt="Position", defaultValue="")
	public String position;
}
