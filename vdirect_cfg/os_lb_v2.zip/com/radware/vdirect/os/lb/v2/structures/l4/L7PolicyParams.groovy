package com.radware.vdirect.os.lb.v2.structures.l4

import com.radware.alteon.workflow.impl.java.Param;

public class L7PolicyParams {
	@Param(type="string", prompt="Policy id", defaultValue="")
	public String id;
	@Param(type="string", prompt="Action", defaultValue="REJECT", values=["REJECT", "REDIRECT_TO_POOL", "REDIRECT_TO_URL"])
	public String action;
	@Param(type="string", prompt="Redirect pool id", defaultValue="None")
	public String redirect_pool_id;
	@Param(type="string", prompt="Redirect URL", defaultValue="None")
	public String redirect_url;
	@Param(type="string", prompt="Policy position in ordered list", defaultValue="1")
	public String position;
	@Param(type="bool", prompt="Is policy enabled?", defaultValue="true")
	public boolean admin_state_up;
	@Param(prompt="Policy rules")
	public L7RuleParams[] rules;
}
