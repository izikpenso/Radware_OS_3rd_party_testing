package com.radware.vdirect.os.lb.v2.structures.persistent

import com.radware.alteon.workflow.impl.java.Param;

public class RealServer {
	@Param(type="string", defaultValue="80")
	public String id;
	@Param(type="int", defaultValue="80")
	public Integer port;
	@Param(type="ip", prompt="Real server IP address", defaultValue="1.1.1.2")
	public String address;
	@Param(type="string", defaultValue="")
	public String name;
}