package com.radware.vdirect.os.lb.v2

import java.util.Map;
import java.beans.PersistenceDelegate;
import java.util.regex.Matcher
import java.util.regex.Pattern

import org.apache.commons.net.util.SubnetUtils;
import org.springframework.beans.factory.annotation.Autowired;

import groovy.transform.ToString
import groovy.transform.EqualsAndHashCode

import com.radware.alteon.beans.adc.*;
import com.radware.alteon.api.*;
import com.radware.alteon.sdk.*
import com.radware.alteon.sdk.containers.SoftAdcInfo;
import com.radware.alteon.sdk.impl.resources.wrapped.WrappedAdcService;
import com.radware.alteon.sdk.rpm.*
import com.radware.alteon.workflow.impl.DeviceConnection;
import com.radware.alteon.workflow.impl.WorkflowAdaptor;
import com.radware.alteon.workflow.impl.java.ConfigurationTemplate;
import com.radware.alteon.api.impl.AlteonCliUtils;
import com.radware.alteon.cli.CliSession;
import com.radware.beans.IReadableBean;
import com.radware.logging.VDirectLogger;
import com.radware.osjava.nova.command.AggregatesExtension.AddHost;
import com.radware.osjava.nova.model.KeyPair;
import com.radware.vdirect.client.api.IAdcSessionBoundObjectFactory;
import com.radware.vdirect.os.lb.v2.structures.l4.HealthMonitorParams;
import com.radware.vdirect.os.lb.v2.structures.l4.ListenerParams;
import com.radware.vdirect.os.lb.v2.structures.l4.MemberParams;
import com.radware.vdirect.os.lb.v2.structures.l4.RealServerParams;
import com.radware.vdirect.os.lb.v2.structures.persistent.StaticRoute;
import com.radware.vdirect.os.lb.v2.structures.persistent.LBVirt;
import com.radware.vdirect.os.lb.v2.structures.persistent.GroupRealServers;
import com.radware.vdirect.os.lb.v2.structures.persistent.RealServer;

public class PersistencyData {
	
	public static final String DISASSOCIATE_HM = "disassociate"
	public static final String ASSOCIATE_HM = "associate"
	public static final String UPDATE_HM = "update"
	
	WorkflowAdaptor workflow
	DeviceConnection connection

	Map<String, LBVirt> virtsMap
	Map<String, Map <String, RealServer>> groupRealServersMap
	Map<String, HealthMonitorParams> groupHMsMap
	Map<String, StaticRoute> staticRoutesMap
	
	public PersistencyData (DeviceConnection connection, WorkflowAdaptor workflow) {
		this.workflow = workflow
		this.connection = connection
		getWFPersistentData()
	}
	
	private void getWFPersistentData () {
		staticRoutesMap = StaticRoutes.getStaticRoutes(connection)
		virtsMap = (Map<String, LBVirt>)workflow['lb_virts']
		groupRealServersMap = (Map<String, Map<String, RealServer>>)workflow['group_real_servers']
		groupHMsMap = (Map<String, HealthMonitorParams>)workflow['group_hms']
	}

	public void persistWFPersistentData () {
		workflow['lb_virts'] = virtsMap
		workflow['group_real_servers'] = groupRealServersMap
		workflow['group_hms'] = groupHMsMap
	}
	
	public void clearWFPersistentData () {
		this.virtsMap.clear()
		this.groupRealServersMap.clear()
		this.groupHMsMap.clear()
		
		persistWFPersistentData()
	}
	
	public boolean addNewStaticRouteData (MemberParams memberParams) {
		if (this.staticRoutesMap.containsKey(memberParams.subnet)) {
			return false
		}
		StaticRoute staticRoute = new StaticRoute()
		staticRoute.destinationIp = memberParams.subnet
		staticRoute.gatewayIp = memberParams.gw
		staticRoute.maskIp = memberParams.mask
		this.staticRoutesMap.put(memberParams.subnet, staticRoute)
		
		return true
	}

	public StaticRoute getStaticRouteData (String destinationIp) {
		return this.staticRoutesMap.get(destinationIp)
	}

	public void addNewVirtData (int virtIndex, String port, int groupIndex) {
		LBVirt lbVirt = new LBVirt()
		lbVirt.index = virtIndex
		lbVirt.port = Integer.valueOf(port)
		lbVirt.groupIndex = groupIndex
		this.virtsMap.put(port, lbVirt)

		this.groupRealServersMap.put(port, new HashMap<String, RealServer>())
	}
		
	public void removeVirtData (String port) {
		this.virtsMap.remove(port)
		this.groupRealServersMap.remove(port)
	}

	public LBVirt getVirtData (String virtPort) {
		return this.virtsMap.get(virtPort)
	}
	
	public Set<String> getVirtKeys () {
		return new HashSet<String>(virtsMap.keySet())
	}

	public Set<String> getDeletedVirtKeys (Set<String> newKeysSet) {
		Set<String> dels = new HashSet<String>(virtsMap.keySet())
		dels.removeAll(newKeysSet)
		return dels
	}
	
	public Set<String> getNewVirtKeys (Set<String> newKeysSet) {
		Set<String> news = new HashSet<String>(newKeysSet)
		news.removeAll(virtsMap.keySet())
		return news
	}

	public void addNewRealServerData (String virtPort, RealServerParams realServerParams) {
		RealServer realServer = new RealServer()
		
		realServer.id = realServerParams.id
		realServer.address = realServerParams.address
		realServer.index = realServerParams.index
		realServer.port = realServerParams.protocol_port
		
		Map<String, RealServer> realServers = this.groupRealServersMap.get(virtPort)
		realServers.put(realServer.id, realServer)
		this.groupRealServersMap.put(virtPort, realServers)
	}

	public void removeRealServerData (String virtPort, String key) {
		Map<String, RealServer> realServers = this.groupRealServersMap.get(virtPort)
		realServers.remove(key)
		this.groupRealServersMap.put(virtPort, realServers)
	}

	public Set<String> getDeletedGroupRealServersKeys (String virtPort, Set<String> newKeysSet) {
		Set<String> dels = new HashSet<String>(this.groupRealServersMap.get(virtPort).keySet())
		dels.removeAll(newKeysSet)
		return dels
	}
	
	public Set<String> getNewGroupRealServersKeys (String virtPort, Set<String> newKeysSet) {
		Set<String> news = new HashSet<String>(newKeysSet)
		news.removeAll(this.groupRealServersMap.get(virtPort).keySet())
		return news
	}

	public Set<String> getUpdatedGroupRealServersKeys (String virtPort, Set<String> newKeysSet) {
		Set<String> updates = new HashSet<String>(this.groupRealServersMap.get(virtPort).keySet())
		updates.retainAll(newKeysSet)
		return updates
	}

	public Map<String, RealServer> getGroupRealServersData (String virtPort) {
		return this.groupRealServersMap.get(virtPort)
	}
	
	public HealthMonitorParams setHealthMonitorData (String groupId, HealthMonitorParams hmParams) {
		return this.groupHMsMap.put(groupId, hmParams)
	}
	
	public HealthMonitorParams getHealthMonitorData (String virtPort) {
		return this.groupHMsMap.get(virtPort)
	}

}