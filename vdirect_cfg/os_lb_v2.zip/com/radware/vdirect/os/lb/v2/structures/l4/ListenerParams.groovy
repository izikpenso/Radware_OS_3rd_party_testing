package com.radware.vdirect.os.lb.v2.structures.l4

import com.radware.alteon.workflow.impl.java.Param;

public class ListenerParams {
	@Param(type="string", prompt="Listener OS UUID", defaultValue="0")
	public String id;
	@Param(type="int", prompt="Listener port", defaultValue="80")
	public int protocol_port;
	@Param(type="string", prompt="Listener protocol", defaultValue="HTTP", values=["HTTP", "HTTPS", "TCP", "TERMINATED_HTTPS"])
	public String protocol;
	@Param(type="int", prompt="Listener connections limit", defaultValue="10")
	public int connection_limit;
	@Param(type="bool", prompt="Is listener enabled?", defaultValue="true")
	public boolean admin_state_up;
	@Param(prompt="Default listener pool", required=false, defaultValue='{"id": "none", "lb_algorithm": "ROUND_ROBIN"}')
	public DefaultPoolParams default_pool;
	@Param(prompt="Default TLS certificate details", required=false, defaultValue='{"id": null, "certificate": "", "intermediates": "", "private_key": "", "passphrase": ""}')
	public TLSCertificateParams default_tls_certificate;
	@Param(prompt="SNI certificate details", required=false, defaultValue='[]')
	public SNITLSCertificateParams[] sni_tls_certificates;
	@Param(prompt="L7 Policies", required=false, defaultValue='[]')
	public L7PolicyParams[] l7_policies;
}
