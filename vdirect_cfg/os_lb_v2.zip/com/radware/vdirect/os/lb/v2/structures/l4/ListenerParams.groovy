package com.radware.vdirect.os.lb.v2.structures.l4

import com.radware.alteon.workflow.impl.java.Param;

public class ListenerParams {
	@Param(type="int", prompt="Listener port", defaultValue="80")
	public int protocol_port;
	@Param(type="string", prompt="Listener protocol", defaultValue="HTTP", values=["HTTP", "HTTPS", "TCP"])
	public String protocol;
	@Param(type="int", prompt="Listener connections limit", defaultValue="10")
	public int connection_limit;
	@Param(type="bool", prompt="Is listener enabled?", defaultValue="true")
	public boolean admin_state_up;
	@Param(prompt="Default listener pool")
	public PoolParams default_pool;
}