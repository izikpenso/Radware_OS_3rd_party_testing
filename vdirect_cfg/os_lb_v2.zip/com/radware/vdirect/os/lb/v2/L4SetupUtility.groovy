package com.radware.vdirect.os.lb.v2

import java.util.Map;
import java.beans.PersistenceDelegate;
import java.util.regex.Matcher
import java.util.regex.Pattern

import org.apache.commons.net.util.SubnetUtils;
import org.springframework.beans.factory.annotation.Autowired;

import groovy.transform.ToString
import groovy.transform.EqualsAndHashCode

import com.radware.alteon.beans.adc.*;
import com.radware.alteon.api.*;
import com.radware.alteon.sdk.*
import com.radware.alteon.sdk.containers.SoftAdcInfo;
import com.radware.alteon.sdk.rpm.*
import com.radware.alteon.workflow.impl.DeviceConnection;
import com.radware.alteon.workflow.impl.WorkflowAdaptor;
import com.radware.alteon.workflow.impl.java.ConfigurationTemplate;
import com.radware.alteon.api.impl.AlteonCliUtils;
import com.radware.alteon.cli.CliSession;
import com.radware.beans.IReadableBean;
import com.radware.logging.VDirectLogger;
import com.radware.osjava.nova.command.AggregatesExtension.AddHost;
import com.radware.osjava.nova.model.KeyPair;
import com.radware.vdirect.client.api.IAdcSessionBoundObjectFactory;
import com.radware.vdirect.os.lb.v2.structures.l4.HealthMonitorParams;
import com.radware.vdirect.os.lb.v2.structures.l4.ListenerParams;
import com.radware.vdirect.os.lb.v2.structures.l4.MemberParams;
import com.radware.vdirect.os.lb.v2.structures.l4.RealServerParams;
import com.radware.vdirect.os.lb.v2.structures.persistent.StaticRoute;
import com.radware.vdirect.os.lb.v2.structures.persistent.LBVirt;
import com.radware.vdirect.os.lb.v2.structures.persistent.GroupRealServers;
import com.radware.vdirect.os.lb.v2.structures.persistent.RealServer;

public class L4SetupUtility {
	
	public static final String DISASSOCIATE_HM = "disassociate"
	public static final String ASSOCIATE_HM = "associate"
	public static final String UPDATE_HM = "update"
	
	WorkflowAdaptor workflow
	ListenerParams[] listeners
	
	Map<Integer, ListenerParams> incommingVirts

	PersistencyData persistencyData
	DeviceConfigurator deviceConfigurator
	
	public L4SetupUtility (DeviceConnection connection, WorkflowAdaptor workflow) {
		this(connection, workflow, [])
	}

	public L4SetupUtility (DeviceConnection connection, WorkflowAdaptor workflow, ListenerParams[] listeners) {
		this.workflow = workflow
		this.listeners = listeners
		
		this.persistencyData = new PersistencyData(connection, workflow)
		this.deviceConfigurator = new DeviceConfigurator(connection, workflow)
		
		initialize()
	}
	
	private void initialize () {
		// Initialize incoming VIRTs configuration
		this.incommingVirts = new HashMap<Integer, ListenerParams>()
		ListenerParams listener
		Iterator<ListenerParams> listenersIter = listeners.iterator()
		while (listenersIter.hasNext()) {
			listener = listenersIter.next()
			incommingVirts.put(String.valueOf(listener.protocol_port), listener)
		}		
	}

	public void persistWFPersistentData () {
		this.persistencyData.persistWFPersistentData()
	}
	
	public void clearWFPersistentData () {
		this.persistencyData.clearWFPersistentData()
	}

	private Map<String, MemberParams> memberParamsArrayToMap (MemberParams[] memberParamsArray) {
		Map<String, MemberParams> memberParamsMap = new HashMap<String, MemberParams>()
		MemberParams memberParams;

		Iterator<MemberParams> memberParamsIter = Arrays.asList(memberParamsArray).iterator()
		while(memberParamsIter.hasNext()) {
			memberParams = memberParamsIter.next()
			memberParamsMap.put(memberParams.id, memberParams)
		}
		return memberParamsMap
	}

	private RealServerParams getRealserverParamsFromMemberParams (MemberParams memberParams) {
		RealServerParams realServerParams = new RealServerParams()
		realServerParams.id = memberParams.id
		realServerParams.address = memberParams.address
		realServerParams.protocol_port = memberParams.protocol_port
		realServerParams.weight = memberParams.weight
		realServerParams.admin_state_up = memberParams.admin_state_up
		realServerParams.subnet = memberParams.subnet
		realServerParams.mask = memberParams.mask
		realServerParams.gw = memberParams.gw

		return realServerParams
	}
							 
	public void setupVirts () {

		LBVirt lbVirt
		
		Set<String> deletedServicePorts = persistencyData.getDeletedVirtKeys(incommingVirts.keySet())
		Set<String> newServicePorts = persistencyData.getNewVirtKeys(incommingVirts.keySet())
		
		Iterator<Integer> toDeleteVirtsIter = deletedServicePorts.iterator()
		while (toDeleteVirtsIter.hasNext()) {
			String portToDelete = toDeleteVirtsIter.next()
			lbVirt = persistencyData.getVirtData(portToDelete)
			
			List<Integer> realServerIds = new ArrayList<Integer>()
			Iterator<RealServer> realServerIter = persistencyData.getGroupRealServersData(portToDelete).values().iterator()
			while(realServerIter.hasNext()) {
				realServerIds.add(realServerIter.next().index)
			}
	
			Integer[] realServerIdsArray = realServerIds.toArray()
			deviceConfigurator.teardownVirt(lbVirt.groupIndex, lbVirt.index, realServerIdsArray)
			
			persistencyData.removeVirtData(portToDelete)
		}

		Integer virtIndex = 0
		Integer groupIndex = 0
		String port
		ListenerParams listenerToCreate
		Iterator<String> toCreateVirtsIter = newServicePorts.iterator()
		while (toCreateVirtsIter.hasNext()) {
			listenerToCreate = incommingVirts.get(toCreateVirtsIter.next())
			port = String.valueOf(listenerToCreate.protocol_port)
			virtIndex = deviceConfigurator.getFreeIndex('SlbNewCfgVirtualServerEntry', virtIndex)
			groupIndex = deviceConfigurator.getFreeIndex('SlbNewCfgGroupEntry', groupIndex)
			deviceConfigurator.configureVirt(
				virtIndex, groupIndex,
				port, listenerToCreate.protocol,
				listenerToCreate.default_pool.lb_algorithm,
				listenerToCreate.default_pool.admin_state_up,
				listenerToCreate.default_pool.sessionpersistence.type,
				listenerToCreate.default_pool.sessionpersistence.cookie_name)

			persistencyData.addNewVirtData (virtIndex, port, groupIndex)
		}
	}

	public void setupRealServers () {
	
		Map<String, RealServer> realServersMap
		Map<String, MemberParams> memberParamsMap
		
		LBVirt lbVirt
		GroupRealServers groupRealServers
		RealServer[] realServers
		
		ListenerParams listener
		String virtPort
		int groupIndex
		
		Iterator<String> serviceIter = incommingVirts.keySet().iterator()
		while (serviceIter.hasNext()) {
			virtPort = serviceIter.next()
			listener = incommingVirts.get(virtPort)
			lbVirt = persistencyData.getVirtData(virtPort)
			groupIndex = lbVirt.groupIndex
			
			realServersMap = persistencyData.getGroupRealServersData(virtPort)
			memberParamsMap = memberParamsArrayToMap(listener.default_pool.members)
			
			Set<String> newServers = persistencyData.getNewGroupRealServersKeys(virtPort, memberParamsMap.keySet())
			Set<String> updatedServers = persistencyData.getUpdatedGroupRealServersKeys(virtPort, memberParamsMap.keySet())
			Set<String> deletedServers = persistencyData.getDeletedGroupRealServersKeys(virtPort, memberParamsMap.keySet())
			
			List<RealServerParams> newRealServers = new ArrayList<RealServerParams>()
			List<RealServerParams> updatedRealServers = new ArrayList<RealServerParams>()
			List<Integer> deletedRealServersIds = new ArrayList<Integer>()
			
			int realServerIndex = 0
			MemberParams memberParams
			RealServerParams realServerParams
			SlbNewCfgRealServerEntry newRealServer
			String realServerKey
			
			Iterator<String> newServersIter = newServers.iterator()
			while (newServersIter.hasNext()) {
				memberParams = memberParamsMap.get(newServersIter.next())
				realServerParams = getRealserverParamsFromMemberParams (memberParams)
				realServerIndex = deviceConfigurator.getFreeIndex('SlbNewCfgRealServerEntry', realServerIndex)
				realServerParams.index = realServerIndex
				persistencyData.addNewRealServerData(virtPort, realServerParams)
				
				newRealServers.add(realServerParams)
			}
			
			Iterator<String> updatesServersIter = updatedServers.iterator()
			while (updatesServersIter.hasNext()) {
				realServerKey = updatesServersIter.next()
				memberParams = memberParamsMap.get(realServerKey)
				realServerParams = getRealserverParamsFromMemberParams (memberParams)
				realServerParams.index = realServersMap.get(realServerKey).index
				
				updatedRealServers.add(realServerParams)
			}

			Iterator<String> deletedServersIter = deletedServers.iterator()
			while (deletedServersIter.hasNext()) {
				realServerKey = deletedServersIter.next()
				
				deletedRealServersIds.add(realServersMap.get(realServerKey).index)
				persistencyData.removeRealServerData (virtPort, realServerKey)
			}

			deviceConfigurator.configureGroup(groupIndex, listener.default_pool.admin_state_up,
					   newRealServers.toArray(new RealServerParams[newRealServers.size()]), 
					   updatedRealServers.toArray(new RealServerParams[updatedRealServers.size()]), 
					   deletedRealServersIds.toArray(new Integer[deletedRealServersIds.size()]))
		}
	}
							 
	public void setupHealthMonitors () {
	
		ListenerParams listener
		String servicePort
		LBVirt lbVirt
		Integer groupIndex
		HealthMonitorParams hmParams
		HealthMonitorParams prevHmParams
		String hmId
		String prevHmId
		
		Iterator<String> serviceIter = incommingVirts.keySet().iterator()
		while (serviceIter.hasNext()) {
			servicePort = serviceIter.next()
			listener = incommingVirts.get(servicePort)
			lbVirt = persistencyData.getVirtData(servicePort)
			groupIndex = lbVirt.groupIndex
			
			hmParams = listener.default_pool.healthmonitor
			prevHmParams = persistencyData.setHealthMonitorData(String.valueOf(groupIndex), hmParams)
			
			hmId = (hmParams == null) ? null :  hmParams.id;
			prevHmId = (prevHmParams == null) ? null :  prevHmParams.id;

			if (hmId != prevHmId) {
				if (prevHmId != null) {
					deviceConfigurator.configureHM(prevHmParams, groupIndex, DISASSOCIATE_HM)
				}
				if (hmId != null) {
					deviceConfigurator.configureHM(hmParams, groupIndex, ASSOCIATE_HM)
				}
			}
			else {
				deviceConfigurator.configureHM(hmParams, groupIndex, UPDATE_HM)
			}
		}
	}

	public void setupStaticRoutes () {

		StaticRoute staticRoute
		Set<StaticRoute> newStaticRoutes = new HashSet<StaticRoute>()
		
		ListenerParams listener
		String servicePort
		Map<String, MemberParams> memberParamsMap
		
		Iterator<String> serviceIter = incommingVirts.keySet().iterator()
		while (serviceIter.hasNext()) {
			servicePort = serviceIter.next()
			listener = incommingVirts.get(servicePort)
			memberParamsMap = memberParamsArrayToMap(listener.default_pool.members)
			MemberParams memberParams

			Iterator<MemberParams> membersIter = memberParamsMap.values().iterator()
			while (membersIter.hasNext()) {
				memberParams = membersIter.next()
				if (persistencyData.addNewStaticRouteData(memberParams)) {
					newStaticRoutes.add(persistencyData.getStaticRouteData(memberParams.subnet))
				}
			}
		}
		
		StaticRoute[] staticRoutesArray = newStaticRoutes.toArray()
		if (staticRoutesArray.length > 0) {
			deviceConfigurator.configureStaticRoutes(staticRoutesArray)
		}
	}

	public void teardown () {
		LBVirt lbVirt
		
		SlbNewCfgVirtualServerEntry lookUpVirt
		SlbNewCfgVirtualServerEntry existingVirt
		SlbNewCfgVirtServicesEntry lookupService
		Integer virtIndex
		
		Integer virtId
		Integer groupId
		String port
		Iterator<String> toDeleteVirtsIter = persistencyData.getVirtKeys().iterator()
		while (toDeleteVirtsIter.hasNext()) {
			port = toDeleteVirtsIter.next()
			lbVirt = persistencyData.getVirtData(port)
			virtId = lbVirt.index
			groupId = lbVirt.groupIndex
			
			List<Integer> realServerIds = new ArrayList<Integer>()
			Iterator<RealServer> realServerIter = persistencyData.getGroupRealServersData(port).values().iterator()
			while(realServerIter.hasNext()) {
				realServerIds.add(realServerIter.next().index)
			}
	
			Integer[] realServerIdsArray = realServerIds.toArray()
			deviceConfigurator.teardownVirt(groupId, virtId, realServerIdsArray)
			
			HealthMonitorParams hmParams = persistencyData.getHealthMonitorData(String.valueOf(groupId))
			deviceConfigurator.configureHM(hmParams, groupId, DISASSOCIATE_HM)
		}
	}
}