package com.radware.vdirect.os.lb.v2.structures.persistent

import com.radware.alteon.workflow.impl.java.Param;

public class StaticRoute {
	@Param(type="ip", prompt="Destination IP")
	public String destinationIp;
	@Param(type="ip", prompt="Gateway IP")
	public String gatewayIp;
	@Param(type="ip", prompt="Mask IP")
	public String maskIp;
}
