package com.radware.vdirect.os.lb.v2.structures.l4

import com.radware.alteon.workflow.impl.java.Param;

public class RealServerParams extends MemberParams {
	@Param(type="string", prompt="Real Server name", defaultValue="")
	public String name;
}