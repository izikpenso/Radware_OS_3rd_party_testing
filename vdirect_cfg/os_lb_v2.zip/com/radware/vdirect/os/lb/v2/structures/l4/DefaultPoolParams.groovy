package com.radware.vdirect.os.lb.v2.structures.l4

import com.radware.alteon.workflow.impl.java.Param;

public class DefaultPoolParams {
	@Param(type="string", prompt="Pool OS UUID", defaultValue="none")
	public String id;
	@Param(prompt="Pool session persistency", defaultValue='{"type": "none", "cookie_name": "none"}')
	public SessionPersistencyParams sessionpersistence;
}
