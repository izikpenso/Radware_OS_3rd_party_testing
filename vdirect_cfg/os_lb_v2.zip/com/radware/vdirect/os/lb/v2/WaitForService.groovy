package com.radware.vdirect.os.lb.v2

import com.radware.alteon.beans.adc.*;
import com.radware.alteon.api.*;
import com.radware.alteon.sdk.*
import com.radware.alteon.sdk.impl.resources.wrapped.WrappedAdcService;
import com.radware.alteon.sdk.rpm.*
import com.radware.alteon.api.impl.AlteonCliUtils;
import com.radware.alteon.cli.AlteonCliSession;
import com.radware.alteon.cli.CliSession;
import com.radware.logging.VDirectLogger;
import com.radware.vdirect.client.api.IAdcObjectFactory;


class WaitForService {

	static void wait (WrappedAdcService service, VDirectLogger logger, IAdcObjectFactory factory) {
		// Guarantees that the service is provisioned or else throws an exception
		logger.info "This may take time... making sure that the service is provisioned."
		logger.info("Provisioning service...")
		service.provision()
		logger.info("Provisioning service complete")

		def timeout = 5 * 60 * 1000
		def start = System.currentTimeMillis()

		AdcConnection adcPrimaryConnection = service.getPrimary();
		logger.info("Locking primary ADC " + adcPrimaryConnection.getAddress());
		factory.lock(adcPrimaryConnection, true);
		logger.info("Locked primary ADC " + adcPrimaryConnection.getAddress())

		try {
			if (service.getRequest().isHa()) {
				AdcConnection adcSecondaryConnection = service.getSecondary();
				logger.info("Locking secondary ADC " + adcSecondaryConnection.getAddress())
				factory.lock(adcSecondaryConnection, true);
				logger.info("Locked secondary ADC " + adcSecondaryConnection.getAddress())
			}
			
			try {
				logger.info("Validating primary SSH available " + adcPrimaryConnection.getAddress())
				validateAdcCLIConnection(service.getPrimary(), start + timeout - System.currentTimeMillis())
				logger.info("Validated primary " + adcPrimaryConnection.getAddress())

				if (service.getRequest().isHa()) {
					logger.info("Validating secondary SSH available " + service.getSecondary().getAddress())
					validateAdcCLIConnection(service.getSecondary(), start + timeout - System.currentTimeMillis())
					logger.info("Validated secondary " + service.getSecondary().getAddress())
				}
			} finally {
				if (service.getRequest().isHa()) {
					AdcConnection adcSecondaryConnection = service.getSecondary();
					factory.unlock(adcSecondaryConnection);
				}
			}
		} finally {
			factory.unlock(adcPrimaryConnection)
		}
	}

	static void validateAdcCLIConnection (AdcCLIConnection connection, long timeout) {

		def SLEEP_TIME = 2000
		def start = System.currentTimeMillis()
		def connected = false
		while (!connected && (System.currentTimeMillis() - start < timeout)) {
			CliSession s = new AlteonCliSession(AlteonCliUtils.convertConnection(connection))
			try {
				s.connect()
				s.close()
				connected = true
			} catch (Exception e) {
				sleep(SLEEP_TIME)
			}
		}
		if (!connected)
			throw new AdcConnectionException("SSH connection timeout to " + connection.getAddress() +
				" in " + System.currentTimeMillis() - start + " ms")
	}
}