package com.radware.vdirect.os.lb.v2.l4

import org.apache.commons.net.util.SubnetUtils;
import org.springframework.beans.factory.annotation.Autowired;

import groovy.transform.ToString
import groovy.transform.EqualsAndHashCode

import com.radware.alteon.beans.adc.*;
import com.radware.alteon.api.*;
import com.radware.alteon.sdk.*
import com.radware.alteon.sdk.containers.SoftAdcInfo;
import com.radware.alteon.sdk.impl.resources.wrapped.WrappedAdcService;
import com.radware.alteon.sdk.rpm.*
import com.radware.alteon.workflow.impl.WorkflowAdaptor;
import com.radware.alteon.api.impl.AlteonCliUtils;
import com.radware.alteon.cli.CliSession;
import com.radware.logging.VDirectLogger;
import com.radware.osjava.nova.model.KeyPair;
import com.radware.vdirect.os.lb.v2.structures.persistent.HAInterface

public class PortsData {

	public static final String PRIMARY = "primary"
	public static final String SECONDARY = "secondary"
	
	private static List<HAInterface> getInterfaces (WrappedAdcService service, WorkflowAdaptor workflow) {
		List<String> conf = new ArrayList<String>()
		IAdcInstance primaryDevice  = service.getPrimaryAdc()
		Map<String, Object> primaryConf = ((SoftAdcInfo)(primaryDevice.getAdcInfo())).getAdvancedConfiguration()
		Iterator<String> primaryKeys = primaryConf.iterator()
		while (primaryKeys.hasNext()) {
			String key = primaryKeys.next()
			if (!key.startsWith("port")) {
				continue
			}
			conf.add("primary:" + key)
		}
		
		if (service.getService().getRequest().isHa()) {
			IAdcInstance secondaryDevice = service.getSecondaryAdc()
			Map<String, Object> secondaryConf = ((SoftAdcInfo)(secondaryDevice.getAdcInfo())).getAdvancedConfiguration()
			Iterator<String> secondaryKeys = secondaryConf.iterator()
			while (secondaryKeys.hasNext()) {
				String key = secondaryKeys.next()
				if (!key.startsWith("port")) {
					continue
				}
				conf.add("secondary:" + key)
			}
		}
		
		String portName
		String portSubnetId
		String propertyName
		String propertyValue
		Map<String, HAInterface> ifsMap = new HashMap<String, HAInterface>()
		List<HAInterface> ifsList = new ArrayList<HAInterface>()
		
		boolean primary
		Iterator<String> keys = conf.iterator()
		while (keys.hasNext()) {
			String deviceKey = keys.next()
			
			String deviceType = deviceKey.substring(0, deviceKey.indexOf(":"))
			String key = deviceKey.substring(deviceKey.indexOf(":") + 1, deviceKey.length())
			if (deviceType.equals("primary")) {
				primary = true
			} 
			else {
				primary = false
			}
			
			List<String> keyValue = key.tokenize("=")
			List<String> keyTokens = keyValue[0].tokenize(".")
			portName = keyTokens[0]
			portSubnetId = keyTokens[1]
			propertyName = keyTokens[2]
			propertyValue = keyValue[1]
		
			// Do not add port0 which is management port
			if (portName.equals("port0")) {
				continue;
			}
			
			HAInterface interf = ifsMap.get(portName)
			if (interf == null) {
				interf = new HAInterface()
				interf.name = portName
				interf.l3_secondary_ip_address = "0.0.0.0"
				interf.vlan = portName.substring(portName.indexOf("port") + 4, portName.length()).toInteger()
				ifsMap.put(portName, interf)
			}
			switch (propertyName) {
				case "ips":
					if (primary) {
						interf.l3_primary_ip_address = propertyValue
					}
					else {
						interf.l3_secondary_ip_address = propertyValue
					}
					break
				case "gateway": 
					if (primary && portName.equals("port1")) {
						workflow['gateway'] = propertyValue
					}
					break
				case "mask":
					SubnetUtils utils = new SubnetUtils(propertyValue);
					interf.ip_netmask = utils.getInfo().getNetmask()
					break
				default:
					break
			}
		}

		ifsList.add(ifsMap.get("port1"))
		ifsList.add(ifsMap.get("port2"))
		return ifsList
	}
	
}