package com.radware.vdirect.os.lb.v2.structures.persistent

import com.radware.alteon.workflow.impl.java.Param;

public class Stats {
	@Param(type="int", defaultValue="0")
	public Integer active_connections;
	@Param(type="int", defaultValue="0")
	public Integer total_connections;
	@Param(type="int", defaultValue="0")
	public Integer bytes_in;
	@Param(type="int", defaultValue="0")
	public Integer bytes_out;
}