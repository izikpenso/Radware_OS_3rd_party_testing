package com.radware.vdirect.os.lb.v2.structures.persistent

import com.radware.alteon.workflow.impl.java.Param;

public class Stats {
	@Param(type="long", defaultValue="0")
	public Long active_connections;
	@Param(type="long", defaultValue="0")
	public Long total_connections;
	@Param(type="long", defaultValue="0")
	public Long bytes_in;
	@Param(type="long", defaultValue="0")
	public Long bytes_out;
}
