package com.radware.vdirect.os.lb.v2.structures.l4

import com.radware.alteon.workflow.impl.java.Param;

public class SessionPersistencyParams {
	@Param(type="string", prompt="Pool session persistence type", defaultValue="none", values=["none", "SOURCE_IP", "HTTP_COOKIE", "APP_COOKIE"])
	public String type;
	@Param(type="string", prompt="Pool session persistence cookie name", defaultValue="none")
	public String cookie_name;
}