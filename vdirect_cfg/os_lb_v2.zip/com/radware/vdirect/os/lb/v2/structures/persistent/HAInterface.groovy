package com.radware.vdirect.os.lb.v2.structures.persistent

import com.radware.alteon.workflow.impl.java.Param;

public class HAInterface {
	@Param(type="string", prompt="Interface Name", defaultValue="data")
	public String name;
	@Param(type="int", prompt="VLAN", defaultValue="1", max=4090, min=1)
	public int vlan;
	@Param(type="ip", prompt="ADC1 Interface IP")
	public String l3_primary_ip_address;
	@Param(type="ip", prompt="ADC2 Interface IP (0.0.0.0 for none)", defaultValue="0.0.0.0")
	public String l3_secondary_ip_address;
	@Param(type="ip", prompt="VRRP Interface IP (0.0.0.0 use ADC1 Interface IP)", defaultValue="0.0.0.0")
	public String vrrp_ip_address;
	@Param(type="ip", prompt="IP Mask", defaultValue="255.255.255.0")
	public String ip_netmask;	
}
