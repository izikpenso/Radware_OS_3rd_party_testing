Radware OpenStack LBaaS v2 workflow package

This workflow is not part of the Radware LBaaS v2 driver code included in OpenStack and should be uploaded to
vDirect appliance separately before using the Radware LBaaS v2 driver.
This ADC workflow is instantiated and run in the vDirect Virtual Machine.
Radware's OpenStack LBaaS v2 driver, uses vDirect REST API calls to activate this workflow and CRUD configuration in the Alteon device.

This workflow includes:
1. This readme.txt file
2. A mandatory XML file called workflow.xml which defines name, description and main groovy workflow class name
   which implements this workflow 
3. Main groovy workflow class (mentioned in workflow.xml) which defines the different states and the transition flow between states
   as well as the workflow functional implementation code.
4. Additional groovy classes files defining data structures used by workflow for parameters specification. 
5. ADC Configuration Template files with extension .vm which are using an extended apache velocity template engine syntax
   and used by the workflow groovy main class for running configuration commands on the Alteon device.
6. Common groovy classes used by workflow 